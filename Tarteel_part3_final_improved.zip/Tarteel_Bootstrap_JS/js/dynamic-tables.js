/*
 * Tarteel - Dynamic data management (Part III, requirement 2)
 * ------------------------------------------------------------
 * HOW THIS FILE WORKS (short overview)
 *   1. Two constructor functions describe the two kinds of information the
 *      site keeps: TarteelProgram (a summer centre) and TarteelLecture.
 *   2. Two arrays (tarteelPrograms, tarteelLectures) are filled with real
 *      information from the site. They start from the default arrays and are
 *      remembered in the browser's localStorage so added rows survive a reload.
 *   3. Two display functions (displayTarteelPrograms / displayTarteelLectures)
 *      draw the rows of the two EMPTY tables that exist in programs.html and
 *      lectures.html. They also apply the search text.
 *   4. A form on each page adds a new object to its array, then calls the
 *      matching display function so the table updates immediately.
 *   5. A search form on each page filters the array and redraws the table.
 * Note: localStorage is only a browser memory; PHP/MySQL replaces it in Part IV.
 */
"use strict";

/* ====================================================================
 * 1. OBJECT TYPES (constructor functions)
 * ==================================================================== */

// A program / educational centre. "this" refers to the new object being built.
function TarteelProgram(number, name, englishName, description, establishment) {
    this.number = number;               // order number shown in the first column ("01")
    this.name = name;                   // Arabic name of the centre
    this.englishName = englishName;     // optional English name
    this.description = description;     // short description
    this.establishment = establishment; // founding year / short note
}

// A lecture with its speaker, date, time and place.
function TarteelLecture(category, title, description, speaker, date, time, location) {
    this.category = category;       // subject + number, e.g. "العقيدة · 01"
    this.title = title;             // lecture title
    this.description = description; // short description
    this.speaker = speaker;         // lecturer name
    this.date = date;               // formatted date text
    this.time = time;               // formatted time text
    this.location = location;       // place of the lecture
}

/* ====================================================================
 * 2. ARRAYS INITIALISED WITH REAL INFORMATION
 * ==================================================================== */

// Default programs: the four centres that appear on the Programs page.
const defaultPrograms = [
    new TarteelProgram("01", "مركز الإمام جابر بن زيد", "Alimam Jaber Center", "هدفنا خدمة المجتمع بتعليم القرآن الكريم والعلوم الشرعية والعربية، وتنمية قدرات الأبناء بالأنشطة والمسابقات المتنوعة.", "تأسس عام 1432هـ / 2011م"),
    new TarteelProgram("02", "مركز رياض العلم", "", "مركز لتعليم القرآن الكريم وعلومه. للتواصل: 97220414", "منذ ١٤٢٥ هـ / ٢٠٠٥ م"),
    new TarteelProgram("03", "مركز الشيخ عبدالله اللزامي رحمه الله", "", "جيلٌ متعلم، عقيدةٌ ثابتة، أخلاقٌ نبوية. للاستفسار: 96876745352", "تأسس عام ١٤٢٣هـ"),
    new TarteelProgram("04", "مدرسة الشيخ حمود بن حميد الصوافي", "", "منصّة تُعنى بتوثيق حياة الشيخ المربي حمود بن حميد الصوافي -حفظه الله- ومركزه الميمون.", "منصّة توثيقية")
];

// Default lectures: the three lectures that appear on the Lectures page.
const defaultLectures = [
    new TarteelLecture("العقيدة · 01", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة"),
    new TarteelLecture("العقيدة · 02", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة"),
    new TarteelLecture("العقيدة · 03", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة")
];

// Read a saved array from localStorage; if nothing is saved (or it is damaged)
// fall back to a copy of the default array. Saved plain objects are turned
// back into real objects by calling the constructor again.
function readSavedArray(key, defaults, Constructor) {
    try {
        const saved = localStorage.getItem(key);
        if (!saved) return defaults.slice();
        return JSON.parse(saved).map(item => new Constructor(...Object.values(item)));
    } catch (error) {
        console.warn("Could not read saved Tarteel data:", error);
        return defaults.slice();
    }
}

// The two live arrays that the whole page works with.
let tarteelPrograms = readSavedArray("tarteelPrograms", defaultPrograms, TarteelProgram);
let tarteelLectures = readSavedArray("tarteelLectures", defaultLectures, TarteelLecture);

// Save both arrays so that rows added by the visitor are still there after reload.
function saveTarteelData() {
    try {
        localStorage.setItem("tarteelPrograms", JSON.stringify(tarteelPrograms));
        localStorage.setItem("tarteelLectures", JSON.stringify(tarteelLectures));
    } catch (error) {
        console.warn("Could not save Tarteel data:", error);
    }
}

/* ====================================================================
 * 3. TWO DISPLAY FUNCTIONS (fill the empty tables)
 * ==================================================================== */

// Add one <td> cell to a row. textContent is used (not innerHTML) so that text
// typed by a visitor is shown as plain text and can never run as HTML.
function addCell(row, value) {
    const cell = document.createElement("td");
    cell.textContent = value || "—";
    row.appendChild(cell);
}

// Show a single "no results" row that spans every column of the table.
function addEmptyRow(tbody, columns, text) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = columns;
    cell.className = "text-center text-secondary py-4";
    cell.textContent = text;
    row.appendChild(cell);
    tbody.appendChild(row);
}

// DISPLAY FUNCTION 1: draws the tarteelPrograms array into the table on programs.html.
//   searchText   - only programs containing this text are shown ("" = show all)
//   highlightKey - number of a program to highlight (used for a newly added row)
function displayTarteelPrograms(searchText = "", highlightKey = null) {
    const tbody = document.getElementById("tarteelProgramsBody");
    if (!tbody) return;                       // this page has no programs table
    tbody.replaceChildren();                  // remove old rows before redrawing

    // Lower-case the query so the search ignores letter case (for English text).
    const query = searchText.trim().toLocaleLowerCase();

    // Keep only the programs whose joined text contains the query.
    const matches = tarteelPrograms.filter(p =>
        [p.number, p.name, p.englishName, p.description, p.establishment]
            .join(" ").toLocaleLowerCase().includes(query));

    // One table row per matching program.
    matches.forEach(p => {
        const row = document.createElement("tr");
        if (p.number === highlightKey) row.className = "table-warning"; // new row stands out
        [p.number, p.name, p.englishName, p.description, p.establishment]
            .forEach(value => addCell(row, value));
        tbody.appendChild(row);
    });

    if (matches.length === 0) addEmptyRow(tbody, 5, "لا توجد برامج مطابقة لبحثك.");

    // Show "x of y" under the search box.
    const counter = document.getElementById("tarteelProgramsCount");
    if (counter) counter.textContent = "عدد النتائج: " + matches.length + " من " + tarteelPrograms.length;
}

// DISPLAY FUNCTION 2: draws the tarteelLectures array into the table on lectures.html.
function displayTarteelLectures(searchText = "", highlightKey = null) {
    const tbody = document.getElementById("tarteelLecturesBody");
    if (!tbody) return;                       // this page has no lectures table
    tbody.replaceChildren();

    const query = searchText.trim().toLocaleLowerCase();

    const matches = tarteelLectures.filter(l =>
        [l.category, l.title, l.description, l.speaker, l.date, l.time, l.location]
            .join(" ").toLocaleLowerCase().includes(query));

    matches.forEach(l => {
        const row = document.createElement("tr");
        if (l.category === highlightKey) row.className = "table-warning";
        [l.category, l.title, l.speaker, l.date, l.time, l.location]
            .forEach(value => addCell(row, value));
        tbody.appendChild(row);
    });

    if (matches.length === 0) addEmptyRow(tbody, 6, "لا توجد محاضرات مطابقة لبحثك.");

    const counter = document.getElementById("tarteelLecturesCount");
    if (counter) counter.textContent = "عدد النتائج: " + matches.length + " من " + tarteelLectures.length;
}

/* ====================================================================
 * 4. FORM VALIDATION HELPER (Bootstrap feedback styles)
 * ==================================================================== */

// Run a list of rules against a form.
// Each rule = { selector, check(value) } where check returns "" when the value
// is valid, or an Arabic error message when it is not. The message is copied into
// the field's .invalid-feedback box; setCustomValidity() marks the field invalid
// so Bootstrap's "was-validated" class paints it red or green. Returns true when
// every rule passes.
function validateWithRules(form, rules) {
    let allValid = true;
    rules.forEach(rule => {
        const field = form.querySelector(rule.selector);
        const message = rule.check(field.value.trim());
        field.setCustomValidity(message);
        const feedback = field.parentElement.querySelector(".invalid-feedback");
        if (feedback && message) feedback.textContent = message;
        if (message) allValid = false;
    });
    form.classList.add("was-validated");
    return allValid;
}

// Re-check the form on every keystroke once the visitor has tried to submit,
// and clear the red/green state when the form is reset.
function enableLiveValidation(form, rules) {
    form.addEventListener("input", function () {
        if (form.classList.contains("was-validated")) validateWithRules(form, rules);
    });
    form.addEventListener("change", function () {
        if (form.classList.contains("was-validated")) validateWithRules(form, rules);
    });
    form.addEventListener("reset", function () {
        form.classList.remove("was-validated");
        form.querySelectorAll("input, select, textarea").forEach(f => f.setCustomValidity(""));
    });
}

// A text rule is valid when it matches a regular expression; otherwise return the message.
function mustMatch(pattern, message) {
    return value => (pattern.test(value) ? "" : message);
}

/* ====================================================================
 * 5. PROGRAMS PAGE: search + add
 * ==================================================================== */

// Rules for the "add program" form (each uses a different regular expression).
const programRules = [
    {   // Arabic or English letters, digits and spaces, 3-80 characters; must not already exist.
        selector: "#newProgramName",
        check: value => {
            if (!/^[\u0600-\u06FFA-Za-z0-9 ]{3,80}$/.test(value)) {
                return "أدخل اسماً من 3 إلى 80 حرفاً (حروف وأرقام ومسافات فقط).";
            }
            const exists = tarteelPrograms.some(p => p.name.trim() === value);
            return exists ? "هذا البرنامج موجود مسبقاً في الجدول." : "";
        }
    },
    {   // English name is optional, but if typed it must contain English characters only.
        selector: "#newProgramEnglish",
        check: value => (value === "" || /^[A-Za-z0-9 '\-]{3,80}$/.test(value))
            ? "" : "الاسم الإنجليزي يقبل حروفاً إنجليزية وأرقاماً فقط (3-80)."
    },
    {   // Description: 10-300 characters and it must contain at least one letter (look-ahead).
        selector: "#newProgramDescription",
        check: mustMatch(/^(?=.*[\u0600-\u06FFA-Za-z]).{10,300}$/s, "اكتب وصفاً من 10 إلى 300 حرف.")
    }
];

function setupProgramsPage() {
    const body = document.getElementById("tarteelProgramsBody");
    if (!body) return;   // not the programs page

    // Draw the table for the first time with all programs.
    displayTarteelPrograms();

    // ---- SEARCH: filter on submit, on typing, and clear with the second button ----
    const searchForm = document.getElementById("programSearchForm");
    const searchInput = document.getElementById("tarteelProgramSearch");
    searchForm.addEventListener("submit", event => {
        event.preventDefault();
        displayTarteelPrograms(searchInput.value);
    });
    searchInput.addEventListener("input", () => displayTarteelPrograms(searchInput.value));
    document.getElementById("programSearchClear").addEventListener("click", () => {
        searchInput.value = "";
        displayTarteelPrograms();
    });

    // ---- ADD: validate, push a new TarteelProgram, then redraw the table ----
    const addForm = document.getElementById("addProgramForm");
    enableLiveValidation(addForm, programRules);
    addForm.addEventListener("submit", event => {
        event.preventDefault();
        if (!validateWithRules(addForm, programRules)) return;   // stop: show red feedback

        // Next order number = (largest existing number + 1), padded to two digits.
        const largest = Math.max(0, ...tarteelPrograms.map(p => Number(p.number) || 0));
        const number = String(largest + 1).padStart(2, "0");

        const program = new TarteelProgram(
            number,
            addForm.querySelector("#newProgramName").value.trim(),
            addForm.querySelector("#newProgramEnglish").value.trim(),
            addForm.querySelector("#newProgramDescription").value.trim(),
            addForm.querySelector("#newProgramEstablishment").value.trim() || "أضيف حديثاً"
        );
        tarteelPrograms.push(program);            // 1) add to the array
        saveTarteelData();                        // 2) remember it
        addForm.reset();                          // 3) clear the form
        searchInput.value = "";                   // 4) show every row, including the new one
        displayTarteelPrograms("", program.number);   // 5) update the table at once
        showTarteelToast("تمت إضافة البرنامج «" + program.name + "» إلى الجدول.");
    });
}

/* ====================================================================
 * 6. LECTURES PAGE: search + add
 * ==================================================================== */

// Convert "18:30" (24-hour value of <input type="time">) to "6:30 مساءً".
function formatArabicTime(value) {
    const [hours, minutes] = value.split(":").map(Number);
    const suffix = hours >= 12 ? "مساءً" : "صباحاً";   // relational operator picks the suffix
    const hour12 = hours % 12 || 12;                    // % converts to 12-hour clock; 0 becomes 12
    return hour12 + ":" + String(minutes).padStart(2, "0") + " " + suffix;
}

// Today's date as "YYYY-MM-DD" so it can be compared with the date input's value.
function todayAsInputValue() {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return now.getFullYear() + "-" + month + "-" + day;
}

const lectureRules = [
    {   // The visitor must choose a subject from the list.
        selector: "#newLectureCategory",
        check: value => (value === "" ? "اختر تصنيف المحاضرة." : "")
    },
    {   // Title: 3-80 characters containing at least one letter (look-ahead).
        selector: "#newLectureTitle",
        check: mustMatch(/^(?=.*[\u0600-\u06FFA-Za-z]).{3,80}$/, "أدخل عنواناً من 3 إلى 80 حرفاً.")
    },
    {   // Speaker: letters, spaces and dots only (no digits), 3-60 characters.
        selector: "#newLectureSpeaker",
        check: mustMatch(/^[\u0600-\u06FFA-Za-z .]{3,60}$/, "اسم المحاضر يقبل حروفاً ومسافات فقط (3-60).")
    },
    {   // Date: required and not earlier than today.
        selector: "#newLectureDate",
        check: value => {
            if (value === "") return "اختر تاريخ المحاضرة.";
            return value < todayAsInputValue() ? "لا يمكن اختيار تاريخ في الماضي." : "";
        }
    },
    {   // Time: required and between 05:00 and 23:30 (&& combines two comparisons).
        selector: "#newLectureTime",
        check: value => {
            if (value === "") return "اختر وقت المحاضرة.";
            return (value >= "05:00" && value <= "23:30") ? "" : "اختر وقتاً بين 5:00 صباحاً و11:30 مساءً.";
        }
    },
    {   // Location: 2-80 characters with at least one letter.
        selector: "#newLectureLocation",
        check: mustMatch(/^(?=.*[\u0600-\u06FFA-Za-z]).{2,80}$/, "أدخل مكان المحاضرة (2-80 حرفاً).")
    },
    {   // Description is optional but limited to 200 characters.
        selector: "#newLectureDescription",
        check: value => (value.length <= 200 ? "" : "الوصف لا يزيد عن 200 حرف.")
    }
];

function setupLecturesPage() {
    const body = document.getElementById("tarteelLecturesBody");
    if (!body) return;   // not the lectures page

    displayTarteelLectures();

    // ---- SEARCH ----
    const searchForm = document.getElementById("lectureSearchForm");
    const searchInput = document.getElementById("tarteelLectureSearch");
    searchForm.addEventListener("submit", event => {
        event.preventDefault();
        displayTarteelLectures(searchInput.value);
    });
    searchInput.addEventListener("input", () => displayTarteelLectures(searchInput.value));
    document.getElementById("lectureSearchClear").addEventListener("click", () => {
        searchInput.value = "";
        displayTarteelLectures();
    });

    // ---- ADD ----
    const addForm = document.getElementById("addLectureForm");
    // The date picker cannot go earlier than today.
    addForm.querySelector("#newLectureDate").min = todayAsInputValue();
    enableLiveValidation(addForm, lectureRules);

    addForm.addEventListener("submit", event => {
        event.preventDefault();
        if (!validateWithRules(addForm, lectureRules)) return;

        // Category label = subject + running number inside that subject ("الفقه · 01").
        const subject = addForm.querySelector("#newLectureCategory").value;
        const sameSubject = tarteelLectures.filter(l => l.category.startsWith(subject + " ·")).length;
        const category = subject + " · " + String(sameSubject + 1).padStart(2, "0");

        // Gregorian date written in Arabic with Latin digits, e.g. "25 نوفمبر 2026".
        const dateValue = addForm.querySelector("#newLectureDate").value;
        const dateText = new Date(dateValue + "T00:00:00")
            .toLocaleDateString("ar-OM-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });

        const lecture = new TarteelLecture(
            category,
            addForm.querySelector("#newLectureTitle").value.trim(),
            addForm.querySelector("#newLectureDescription").value.trim(),
            addForm.querySelector("#newLectureSpeaker").value.trim(),
            dateText,
            formatArabicTime(addForm.querySelector("#newLectureTime").value),
            addForm.querySelector("#newLectureLocation").value.trim()
        );
        tarteelLectures.push(lecture);
        saveTarteelData();
        addForm.reset();
        searchInput.value = "";
        displayTarteelLectures("", lecture.category);
        showTarteelToast("تمت إضافة المحاضرة «" + lecture.title + "» إلى الجدول.");
    });
}

// Run the setup that matches the page that has just loaded
// (each function does nothing when its table is not on the page).
document.addEventListener("DOMContentLoaded", function () {
    setupProgramsPage();
    setupLecturesPage();
});
