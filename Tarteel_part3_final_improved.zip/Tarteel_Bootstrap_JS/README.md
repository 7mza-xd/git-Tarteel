# Tarteel (ترتيل) – COMP3700 Course Project, Part III

Arabic (RTL) Quran-learning website built with **HTML5, Bootstrap 5.3 (RTL) and vanilla JavaScript**.
Hosted site: https://tarteel.site.je

## Team
- Hamza Mohammed Al Busafi (146456)
- Yousif said Al Badi (150259)
- Alkhalil Ibrahim Al Shabibi (140498)

## Features by requirement
| Requirement | Where |
|---|---|
| Bootstrap grid, navbar, cards, forms, utilities | every page |
| Bootstrap interactive components | collapsible navbar, registration modals (`programs.html`), thank-you modal + accordion (`questionnaire.html`), toasts (`js/tarteel-ui.js`) |
| Bootstrap form validation (`was-validated`, `is-invalid`) | contact, registration, questionnaire, add-program, add-lecture, calculator |
| Two constructors + two arrays + two display functions | `js/dynamic-tables.js` (`TarteelProgram`, `TarteelLecture`, `displayTarteelPrograms`, `displayTarteelLectures`) |
| Add + search forms that update the tables | `programs.html`, `lectures.html` |
| Questionnaire with custom regex validation | `questionnaire.html`, `js/questionnaire.js` |
| Zakat calculator (nisab, debts, hawl conditions) | `cal.html`, `js/cal.js` |
| Fun page – Quran verse word-ordering game | `funpage.html`, `js/funpage.js` |
| Moving welcome banner with live date/time + 3-second photo gallery | `index.html`, `js/home.js` |

## Project structure
```
index.html  programs.html  lectures.html  about-us.html  contact-us.html
questionnaire.html  cal.html  funpage.html  admin.html
css/tarteel-theme.css          brand colours applied on top of Bootstrap
js/tarteel-ui.js               shared Bootstrap toast helper
js/dynamic-tables.js           constructors, arrays, tables, add + search
js/questionnaire.js            questionnaire validation + progress bar
js/cal.js                      zakat calculator logic
js/funpage.js                  word-ordering game
js/home.js                     banner + gallery
js/contact-validation.js  js/registration-validation.js
images/
```

## Run locally
No build step. Open `index.html` in a browser (an internet connection is needed for the Bootstrap CDN and the Tajawal font).

## Notes
- Rows added in the Programs/Lectures tables are saved in the browser's `localStorage`; PHP/MySQL replaces this in Part IV.
- Forms validate on the front end only; there is no server yet.
