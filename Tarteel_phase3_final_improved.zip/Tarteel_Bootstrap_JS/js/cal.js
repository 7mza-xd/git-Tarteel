/*
  Tarteel - Zakat Calculator (Part III, requirement 4)
  ------------------------------------------------------------
  WHY THIS PAGE: Tarteel teaches Islamic sciences, and zakat on money is a core
  practical rule of fiqh. The calculator shows how the rule works.

  THE FORMULAS
      nisab      = nisab weight (85 g gold OR 595 g silver) x price of one gram
      totalAssets= cash + gold/silver savings + trade goods
      netWealth  = totalAssets - debts            (never below zero)
      zakat      = netWealth x 2.5%     ONLY IF  netWealth >= nisab  AND  one lunar year (hawl) has passed

  HOW THE CODE WORKS
      1. The page elements are read once and stored in constants.
      2. calculateZakat() runs every time the visitor types or changes anything
         (so no "Calculate" button is needed).
      3. Every number is validated first; a wrong value gets Bootstrap's
         "is-invalid" class and its red .invalid-feedback message.
      4. Arithmetic operators (+ - * /) compute the amounts; relational
         operators (>= <) and logical operators (&& || !) decide which message
         and which result is shown.
*/
"use strict";

// ---------------------------------------------------------------- constants
// Nisab weights in grams: 85 g of pure gold, or 595 g of silver.
const NISAB_GRAMS = { gold: 85, silver: 595 };
// Zakat rate on money = 2.5% (one fortieth).
const ZAKAT_RATE = 0.025;

// ---------------------------------------------------------- page elements
const basisSelect = document.getElementById("nisabBasis");   // gold or silver
const priceInput = document.getElementById("goldPrice");     // price of one gram
const cashInput = document.getElementById("money");          // cash and bank savings
const metalsInput = document.getElementById("metalsValue");  // gold/silver savings value
const tradeInput = document.getElementById("tradeGoods");    // trade goods value
const debtsInput = document.getElementById("debts");         // debts to deduct
const hawlSwitch = document.getElementById("hawl");          // one lunar year passed?

const priceLabel = document.getElementById("priceLabel");
const nisabLabel = document.getElementById("nisabLabel");
const nisabResult = document.getElementById("nisabResult");
const netWealthResult = document.getElementById("netWealthResult");
const zakatResult = document.getElementById("zakatResult");
const zakatGrams = document.getElementById("zakatGrams");
const message = document.getElementById("message");
const nisabPercent = document.getElementById("nisabPercent");
const nisabProgress = document.getElementById("nisabProgress");
const nisabProgressWrap = document.getElementById("nisabProgressWrap");
const resetBtn = document.getElementById("resetBtn");

// ------------------------------------------------------------------ helpers
// Write an amount with 3 decimals (Omani rial has 1000 baisa).
function formatMoney(number) {
    return number.toFixed(3) + " ر.ع";
}

// Show a message inside the Bootstrap alert box. "type" is a Bootstrap colour name.
function showMessage(type, text) {
    message.className = "alert alert-" + type + " mb-0";
    message.textContent = text;
}

// Read one numeric input.
//   - an empty optional field counts as 0
//   - an empty required field (the price) gives null but is not painted red,
//     so the page does not start with an error on it
//   - text, NaN, negative numbers (and zero for the required price) are rejected
// The field is painted red/green with Bootstrap classes.
// Returns the number, or null when it cannot be used.
function readAmount(input, isRequired) {
    const text = input.value.trim();

    // Empty field: no colour, and 0 for optional fields.
    if (text === "") {
        input.classList.remove("is-invalid", "is-valid");
        return isRequired ? null : 0;
    }

    const number = Number(text);
    // || joins the bad cases: not a real number, negative, or zero when the field is required.
    const invalid = !Number.isFinite(number) || number < 0 || (isRequired && number === 0);

    input.classList.toggle("is-invalid", invalid);
    input.classList.toggle("is-valid", !invalid);
    return invalid ? null : number;
}

// Put every result back to zero (used when an input is wrong or empty).
function clearResults() {
    netWealthResult.textContent = formatMoney(0);
    zakatResult.textContent = formatMoney(0);
    zakatGrams.textContent = "";
    nisabPercent.textContent = "0%";
    nisabProgress.style.width = "0%";
    nisabProgressWrap.setAttribute("aria-valuenow", "0");
}

// ------------------------------------------------------------ main function
function calculateZakat() {
    // Step 1 - adapt the labels to the chosen basis (gold or silver).
    const basis = basisSelect.value;                       // "gold" or "silver"
    const metalName = basis === "gold" ? "الذهب" : "الفضة";
    priceLabel.textContent = "سعر جرام " + metalName + (basis === "gold" ? " عيار 24" : "") + " (ر.ع)";
    nisabLabel.textContent = "النصاب (" + NISAB_GRAMS[basis] + " جرام " + metalName + ")";

    // Step 2 - read and validate all inputs.
    const price = readAmount(priceInput, true);            // required, must be > 0
    const cash = readAmount(cashInput, false);
    const metals = readAmount(metalsInput, false);
    const trade = readAmount(tradeInput, false);
    const debts = readAmount(debtsInput, false);

    // If the price is missing or wrong, nothing can be calculated (nisab needs it).
    if (price === null) {
        nisabResult.textContent = formatMoney(0);
        clearResults();
        showMessage("secondary", "أدخل سعر الجرام أولاً (رقم أكبر من صفر).");
        return;
    }

    // Step 3 - nisab = weight x price.
    const nisab = NISAB_GRAMS[basis] * price;
    nisabResult.textContent = formatMoney(nisab);

    // If any optional amount is invalid (null), stop and ask for a correction.
    if (cash === null || metals === null || trade === null || debts === null) {
        clearResults();
        showMessage("danger", "تحقق من المبالغ المدخلة: يجب أن تكون أرقاماً صفراً أو أكثر.");
        return;
    }

    // Step 4 - net wealth = everything owned minus debts (never negative).
    const totalAssets = cash + metals + trade;
    const netWealth = Math.max(0, totalAssets - debts);
    netWealthResult.textContent = formatMoney(netWealth);

    // Step 5 - progress toward the nisab, capped at 100% for the progress bar.
    const percent = Math.min(100, Math.round((netWealth / nisab) * 100));
    nisabPercent.textContent = percent + "%";
    nisabProgress.style.width = percent + "%";
    nisabProgressWrap.setAttribute("aria-valuenow", String(percent));

    // Step 6 - decide the result with relational and logical operators.
    const reachedNisab = netWealth >= nisab;               // relational: is wealth at or above nisab?
    const hawlDone = hawlSwitch.checked;                   // did a full lunar year pass?
    let zakat = 0;

    if (reachedNisab && hawlDone) {
        // Both conditions are true (&&): zakat is due on the whole net wealth.
        zakat = netWealth * ZAKAT_RATE;
        showMessage("success", "تجب الزكاة: بلغ صافي مالك النصاب وتمّ الحول. الزكاة = " + formatMoney(netWealth) + " × 2.5%.");
    } else if (reachedNisab && !hawlDone) {
        // Nisab reached but the year is not complete: wait.
        showMessage("warning", "بلغ مالك النصاب لكن لم يتمّ الحول، فلا زكاة الآن. أعد الحساب عند تمام الحول.");
    } else if (totalAssets >= nisab && debts > 0) {
        // Without the debts the wealth would reach nisab: explain why zakat is not due.
        showMessage("warning", "مالك قبل الديون يبلغ النصاب، لكن الديون خفّضته دون النصاب، فلا زكاة وفق هذا الحساب.");
    } else {
        // Below nisab: show how much is still missing (subtraction).
        const missing = nisab - netWealth;
        showMessage("warning", "صافي مالك أقل من النصاب بمقدار " + formatMoney(missing) + "، فلا تجب الزكاة.");
    }

    // Step 7 - show the zakat and what it is worth in grams of the chosen metal (division).
    zakatResult.textContent = formatMoney(zakat);
    zakatGrams.textContent = zakat > 0
        ? "تعادل نحو " + (zakat / price).toFixed(2) + " جرام من " + metalName
        : "";
}

// ----------------------------------------------------------------- events
// Recalculate immediately whenever any field changes.
[basisSelect, priceInput, cashInput, metalsInput, tradeInput, debtsInput].forEach(function (field) {
    field.addEventListener("input", calculateZakat);
});
hawlSwitch.addEventListener("change", calculateZakat);

// Reset button: clear every field and its red/green state, then recalculate.
resetBtn.addEventListener("click", function () {
    [priceInput, cashInput, metalsInput, tradeInput, debtsInput].forEach(function (field) {
        field.value = "";
        field.classList.remove("is-invalid", "is-valid");
    });
    basisSelect.value = "gold";
    hawlSwitch.checked = false;
    calculateZakat();
    showMessage("secondary", "أدخل سعر الجرام ثم بياناتك المالية.");
});

// Run once when the page opens so the labels and results start in a clean state.
calculateZakat();
showMessage("secondary", "أدخل سعر الجرام ثم بياناتك المالية.");
