/*
 * Tarteel - Administration page (admin.html)
 * ------------------------------------------------------------
 * Only the administrator can ADD, EDIT or DELETE programs and lectures.
 * The public pages (programs.html, lectures.html) only show the tables and
 * let visitors search them.
 *
 * HOW THIS FILE WORKS
 *   1. Sign-in: the admin panel stays hidden until the correct user name and
 *      password are typed. The "signed in" flag lives in sessionStorage, so it
 *      ends when the browser tab is closed.
 *   2. Shared helpers validate forms with regular expressions and show Bootstrap
 *      red/green feedback.
 *   3. One form per record type works in two modes: ADD (empty form) and EDIT
 *      (fields filled from the chosen row). Saving updates the array in
 *      js/dynamic-tables.js, saves it, and redraws the table at once with the
 *      two display functions.
 *   4. Delete buttons open a Bootstrap confirmation modal first.
 *   5. The counters at the top of the page always show the real array sizes.
 *
 * SECURITY NOTE: this sign-in runs in the browser, so it only hides the panel
 * for a normal visitor; anyone who reads this file can see the password. Real
 * protection (PHP sessions and a database) is planned for Part IV.
 */
"use strict";

// Demo credentials. Change them here (and in the README) if needed.
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "Tarteel@2026";
// Name of the flag saved in sessionStorage after a successful sign-in.
const ADMIN_FLAG = "tarteelAdminSignedIn";

/* ====================================================================
 * 1. SHARED HELPERS
 * ==================================================================== */

// Run a list of rules against a form.
// Each rule = { selector, check(value) }; check returns "" when the value is
// valid, or an Arabic error message when it is not. The message is copied into
// the field's .invalid-feedback box and setCustomValidity() marks the field
// invalid so Bootstrap's "was-validated" class paints it red or green.
// Returns true when every rule passes.
function validateWithRules(form, rules) {
    let allValid = true;
    rules.forEach(rule => {
        const field = form.querySelector(rule.selector);
        const message = rule.check(field.value.trim());
        field.setCustomValidity(message);
        const feedback = field.parentElement.querySelector(".invalid-feedback");
        if (feedback && message) feedback.textContent = message;
        if (message) allValid = false;
    });
    form.classList.add("was-validated");
    return allValid;
}

// Re-check the form while typing (after the first submit attempt) and clear the
// red/green state when the form is reset.
function enableLiveValidation(form, rules) {
    const recheck = () => { if (form.classList.contains("was-validated")) validateWithRules(form, rules); };
    form.addEventListener("input", recheck);
    form.addEventListener("change", recheck);
    form.addEventListener("reset", () => clearFormState(form));
}

// Remove the red/green state of a form.
function clearFormState(form) {
    form.classList.remove("was-validated");
    form.querySelectorAll("input, select, textarea").forEach(field => field.setCustomValidity(""));
}

// A text rule is valid when it matches a regular expression; otherwise return the message.
function mustMatch(pattern, message) {
    return value => (pattern.test(value) ? "" : message);
}

// Number as two digits: 3 -> "03".
const twoDigits = number => String(number).padStart(2, "0");

// Today's date as "YYYY-MM-DD" so it can be compared with a date input's value.
function todayAsInputValue() {
    const now = new Date();
    return now.getFullYear() + "-" + twoDigits(now.getMonth() + 1) + "-" + twoDigits(now.getDate());
}

// Convert "18:30" (24-hour value of <input type="time">) to "6:30 مساءً".
function formatArabicTime(value) {
    const [hours, minutes] = value.split(":").map(Number);
    const suffix = hours >= 12 ? "مساءً" : "صباحاً";   // relational operator picks the suffix
    const hour12 = hours % 12 || 12;                    // % converts to a 12-hour clock; 0 becomes 12
    return hour12 + ":" + twoDigits(minutes) + " " + suffix;
}

// Gregorian date written in Arabic with Latin digits, e.g. "25 نوفمبر 2026".
function formatArabicDate(value) {
    return new Date(value + "T00:00:00")
        .toLocaleDateString("ar-OM-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
}

// After a deletion the visible numbers are rebuilt without gaps:
// programs become 01, 02, 03 ... and lectures are numbered inside each subject.
function renumberRecords() {
    tarteelPrograms.forEach((program, i) => { program.number = twoDigits(i + 1); });
    const counters = {};                                   // running number per subject
    tarteelLectures.forEach(lecture => {
        const subject = lecture.category.split(" ·")[0];   // "الفقه · 02" -> "الفقه"
        counters[subject] = (counters[subject] || 0) + 1;
        lecture.category = subject + " · " + twoDigits(counters[subject]);
    });
}

// Update the four counters at the top of the admin page.
function updateAdminStats() {
    const lecturesBox = document.getElementById("statLectures");
    const programsBox = document.getElementById("statPrograms");
    if (lecturesBox) lecturesBox.textContent = tarteelLectures.length;
    if (programsBox) programsBox.textContent = tarteelPrograms.length;
}

/* ====================================================================
 * 2. SIGN-IN / SIGN-OUT
 * ==================================================================== */

function setupAdminLogin() {
    const loginSection = document.getElementById("adminLogin");
    const panel = document.getElementById("adminPanel");
    const loginForm = document.getElementById("adminLoginForm");
    const userField = document.getElementById("adminUser");
    const passField = document.getElementById("adminPass");
    if (!loginSection || !panel) return;

    // Show the panel when signed in, the sign-in card otherwise.
    function showState() {
        const signedIn = sessionStorage.getItem(ADMIN_FLAG) === "yes";
        panel.classList.toggle("d-none", !signedIn);
        loginSection.classList.toggle("d-none", signedIn);
    }
    showState();

    // Mark one login field invalid and write its message into its .invalid-feedback box.
    function flag(field, message) {
        field.setCustomValidity(message);
        const feedback = field.parentElement.querySelector(".invalid-feedback");
        if (feedback && message) feedback.textContent = message;
    }

    loginForm.addEventListener("submit", event => {
        event.preventDefault();
        const user = userField.value.trim();
        const pass = passField.value;
        // An empty field gets its own message; filled but wrong values get the general one.
        // (The general message does not say which of the two is wrong.)
        const wrong = user !== ADMIN_USERNAME || pass !== ADMIN_PASSWORD;
        const general = "اسم المستخدم أو كلمة المرور غير صحيحة.";
        flag(userField, user === "" ? "أدخل اسم المستخدم." : (wrong ? general : ""));
        flag(passField, pass === "" ? "أدخل كلمة المرور." : (wrong ? general : ""));
        loginForm.classList.add("was-validated");
        if (wrong) return;                                  // stay on the sign-in card

        sessionStorage.setItem(ADMIN_FLAG, "yes");
        loginForm.reset();
        loginForm.classList.remove("was-validated");
        showState();
        showTarteelToast("تم تسجيل الدخول بنجاح. مرحباً بك في لوحة الإدارة.");
    });
    // Typing again clears the errors so the form can be re-checked.
    [userField, passField].forEach(f => f.addEventListener("input", () => {
        userField.setCustomValidity(""); passField.setCustomValidity("");
    }));

    document.getElementById("adminLogout").addEventListener("click", () => {
        sessionStorage.removeItem(ADMIN_FLAG);
        showState();
    });
}

/* ====================================================================
 * 3. PROGRAMS: add / edit
 * ==================================================================== */

// Position (index) of the program being edited, or null when the form is in ADD mode.
let editingProgramIndex = null;

// Rules for the program form (each field uses a different regular expression).
const programRules = [
    {   // Arabic or English letters, digits and spaces (3-80); must not already exist.
        selector: "#newProgramName",
        check: value => {
            if (!/^[\u0600-\u06FFA-Za-z0-9 ]{3,80}$/.test(value)) {
                return "أدخل اسماً من 3 إلى 80 حرفاً (حروف وأرقام ومسافات فقط).";
            }
            // When editing, the program being edited is not counted as a duplicate of itself.
            const exists = tarteelPrograms.some((p, i) => i !== editingProgramIndex && p.name.trim() === value);
            return exists ? "هذا البرنامج موجود مسبقاً في الجدول." : "";
        }
    },
    {   // English name is optional; if typed it must use English characters only.
        selector: "#newProgramEnglish",
        check: value => (value === "" || /^[A-Za-z0-9 '\-]{3,80}$/.test(value))
            ? "" : "الاسم الإنجليزي يقبل حروفاً إنجليزية وأرقاماً فقط (3-80)."
    },
    {   // Description: 10-300 characters containing at least one letter (look-ahead).
        selector: "#newProgramDescription",
        check: mustMatch(/^(?=.*[\u0600-\u06FFA-Za-z]).{10,300}$/s, "اكتب وصفاً من 10 إلى 300 حرف.")
    }
];

function setupProgramsAdmin() {
    const form = document.getElementById("programForm");
    const tbody = document.getElementById("tarteelProgramsBody");
    if (!form || !tbody) return;

    const searchInput = document.getElementById("tarteelProgramSearch");
    const title = document.getElementById("programFormTitle");
    const submitButton = document.getElementById("programSubmitBtn");
    const cancelButton = document.getElementById("programCancelEdit");

    // Switch the form between ADD mode and EDIT mode (texts and buttons change).
    function setMode(index) {
        editingProgramIndex = index;
        const editing = index !== null;
        title.textContent = editing ? "تعديل البرنامج" : "إضافة برنامج جديد";
        submitButton.textContent = editing ? "حفظ التعديلات" : "إضافة البرنامج";
        cancelButton.classList.toggle("d-none", !editing);
    }

    enableLiveValidation(form, programRules);
    // "Reset" button: clear the fields and go back to ADD mode.
    form.addEventListener("reset", () => setMode(null));
    cancelButton.addEventListener("click", () => form.reset());

    // Edit / Delete buttons inside the table (event delegation: one listener for all rows).
    tbody.addEventListener("click", event => {
        const button = event.target.closest("button[data-action]");
        if (!button) return;
        const index = Number(button.dataset.index);
        const program = tarteelPrograms[index];

        if (button.dataset.action === "edit") {
            clearFormState(form);
            form.querySelector("#newProgramName").value = program.name;
            form.querySelector("#newProgramEnglish").value = program.englishName;
            form.querySelector("#newProgramDescription").value = program.description;
            form.querySelector("#newProgramEstablishment").value = program.establishment;
            setMode(index);
            form.scrollIntoView({ behavior: "smooth", block: "center" });
            form.querySelector("#newProgramName").focus();
        } else {
            askToDelete("program", index, program.name);
        }
    });

    // Save: validate, then add a new object or update the edited one.
    form.addEventListener("submit", event => {
        event.preventDefault();
        if (!validateWithRules(form, programRules)) return;     // stop: red feedback is shown

        const values = {
            name: form.querySelector("#newProgramName").value.trim(),
            englishName: form.querySelector("#newProgramEnglish").value.trim(),
            description: form.querySelector("#newProgramDescription").value.trim(),
            establishment: form.querySelector("#newProgramEstablishment").value.trim()
        };

        const adding = editingProgramIndex === null;   // remember the mode: form.reset() below switches it to ADD
        let highlight;
        if (adding) {
            // ADD: next number = largest existing number + 1, as two digits.
            const largest = Math.max(0, ...tarteelPrograms.map(p => Number(p.number) || 0));
            const program = new TarteelProgram(twoDigits(largest + 1), values.name, values.englishName,
                values.description, values.establishment || "أضيف حديثاً");
            tarteelPrograms.push(program);                      // 1) add to the array
            highlight = program.number;
            showTarteelToast("تمت إضافة البرنامج «" + program.name + "» إلى الجدول.");
        } else {
            // EDIT: overwrite the fields of the existing object (its number stays).
            const program = tarteelPrograms[editingProgramIndex];
            Object.assign(program, values);
            highlight = program.number;
            showTarteelToast("تم حفظ تعديلات البرنامج «" + program.name + "».");
        }
        saveTarteelData();                                      // 2) remember the change
        form.reset();                                           // 3) clear the form (back to ADD mode)
        // 4) a new row is shown among all rows; after an edit the search text is kept.
        if (adding && searchInput) searchInput.value = "";
        displayTarteelPrograms(searchInput ? searchInput.value : "", highlight);   // 5) redraw at once
        updateAdminStats();
    });
}

/* ====================================================================
 * 4. LECTURES: add / edit
 * ==================================================================== */

// Position (index) of the lecture being edited, or null in ADD mode.
let editingLectureIndex = null;

const lectureRules = [
    {   // The administrator must choose a subject from the list.
        selector: "#newLectureCategory",
        check: value => (value === "" ? "اختر تصنيف المحاضرة." : "")
    },
    {   // Title: 3-80 characters containing at least one letter (look-ahead).
        selector: "#newLectureTitle",
        check: mustMatch(/^(?=.*[\u0600-\u06FFA-Za-z]).{3,80}$/, "أدخل عنواناً من 3 إلى 80 حرفاً.")
    },
    {   // Speaker: letters, spaces and dots only (no digits), 3-60 characters.
        selector: "#newLectureSpeaker",
        check: mustMatch(/^[\u0600-\u06FFA-Za-z .]{3,60}$/, "اسم المحاضر يقبل حروفاً ومسافات فقط (3-60).")
    },
    {   // Date: required; a past date is refused unless it is the lecture's own saved date.
        selector: "#newLectureDate",
        check: value => {
            if (value === "") return "اختر تاريخ المحاضرة.";
            const ownDate = editingLectureIndex === null ? "" : tarteelLectures[editingLectureIndex].dateValue;
            return (value < todayAsInputValue() && value !== ownDate) ? "لا يمكن اختيار تاريخ في الماضي." : "";
        }
    },
    {   // Time: required and between 05:00 and 23:30 (&& combines two comparisons).
        selector: "#newLectureTime",
        check: value => {
            if (value === "") return "اختر وقت المحاضرة.";
            return (value >= "05:00" && value <= "23:30") ? "" : "اختر وقتاً بين 5:00 صباحاً و11:30 مساءً.";
        }
    },
    {   // Location: 2-80 characters with at least one letter.
        selector: "#newLectureLocation",
        check: mustMatch(/^(?=.*[\u0600-\u06FFA-Za-z]).{2,80}$/, "أدخل مكان المحاضرة (2-80 حرفاً).")
    },
    {   // Description is optional but limited to 200 characters.
        selector: "#newLectureDescription",
        check: value => (value.length <= 200 ? "" : "الوصف لا يزيد عن 200 حرف.")
    }
];

function setupLecturesAdmin() {
    const form = document.getElementById("lectureForm");
    const tbody = document.getElementById("tarteelLecturesBody");
    if (!form || !tbody) return;

    const searchInput = document.getElementById("tarteelLectureSearch");
    const title = document.getElementById("lectureFormTitle");
    const submitButton = document.getElementById("lectureSubmitBtn");
    const cancelButton = document.getElementById("lectureCancelEdit");

    function setMode(index) {
        editingLectureIndex = index;
        const editing = index !== null;
        title.textContent = editing ? "تعديل المحاضرة" : "إضافة محاضرة جديدة";
        submitButton.textContent = editing ? "حفظ التعديلات" : "إضافة المحاضرة";
        cancelButton.classList.toggle("d-none", !editing);
    }

    enableLiveValidation(form, lectureRules);
    form.addEventListener("reset", () => setMode(null));
    cancelButton.addEventListener("click", () => form.reset());

    // Edit / Delete buttons inside the lectures table.
    tbody.addEventListener("click", event => {
        const button = event.target.closest("button[data-action]");
        if (!button) return;
        const index = Number(button.dataset.index);
        const lecture = tarteelLectures[index];

        if (button.dataset.action === "edit") {
            clearFormState(form);
            form.querySelector("#newLectureCategory").value = lecture.category.split(" ·")[0];
            form.querySelector("#newLectureTitle").value = lecture.title;
            form.querySelector("#newLectureSpeaker").value = lecture.speaker;
            form.querySelector("#newLectureLocation").value = lecture.location;
            form.querySelector("#newLectureDate").value = lecture.dateValue;
            form.querySelector("#newLectureTime").value = lecture.timeValue;
            form.querySelector("#newLectureDescription").value = lecture.description;
            setMode(index);
            form.scrollIntoView({ behavior: "smooth", block: "center" });
            form.querySelector("#newLectureTitle").focus();
        } else {
            askToDelete("lecture", index, lecture.title);
        }
    });

    form.addEventListener("submit", event => {
        event.preventDefault();
        if (!validateWithRules(form, lectureRules)) return;

        const subject = form.querySelector("#newLectureCategory").value;
        const dateValue = form.querySelector("#newLectureDate").value;
        const timeValue = form.querySelector("#newLectureTime").value;
        const fields = {
            title: form.querySelector("#newLectureTitle").value.trim(),
            description: form.querySelector("#newLectureDescription").value.trim(),
            speaker: form.querySelector("#newLectureSpeaker").value.trim(),
            date: formatArabicDate(dateValue),
            time: formatArabicTime(timeValue),
            location: form.querySelector("#newLectureLocation").value.trim(),
            dateValue: dateValue,
            timeValue: timeValue
        };

        // Number of OTHER lectures that already belong to this subject (the lecture being edited is skipped).
        const sameSubject = tarteelLectures.filter((l, i) => i !== editingLectureIndex && l.category.startsWith(subject + " ·")).length;
        let highlight;
        if (editingLectureIndex === null) {
            // ADD: label = subject + running number inside that subject ("الفقه · 01").
            const lecture = new TarteelLecture(subject + " · " + twoDigits(sameSubject + 1), fields.title,
                fields.description, fields.speaker, fields.date, fields.time, fields.location,
                fields.dateValue, fields.timeValue);
            tarteelLectures.push(lecture);
            highlight = lecture.category;
            if (searchInput) searchInput.value = "";            // show every row, including the new one
            showTarteelToast("تمت إضافة المحاضرة «" + lecture.title + "» إلى الجدول.");
        } else {
            // EDIT: update the fields. The label changes only when the subject changed.
            const lecture = tarteelLectures[editingLectureIndex];
            const subjectChanged = lecture.category.split(" ·")[0] !== subject;
            Object.assign(lecture, fields);
            if (subjectChanged) lecture.category = subject + " · " + twoDigits(sameSubject + 1);
            highlight = lecture.category;
            showTarteelToast("تم حفظ تعديلات المحاضرة «" + lecture.title + "».");
        }
        saveTarteelData();
        form.reset();
        displayTarteelLectures(searchInput ? searchInput.value : "", highlight);
        updateAdminStats();
    });
}

/* ====================================================================
 * 5. DELETE (with a Bootstrap confirmation modal)
 * ==================================================================== */

// What the administrator asked to delete; used when "Delete" is confirmed in the modal.
let pendingDelete = null;

function askToDelete(type, index, name) {
    pendingDelete = { type: type, index: index };
    document.getElementById("deleteModalText").textContent =
        "هل تريد حذف " + (type === "program" ? "البرنامج" : "المحاضرة") + " «" + name + "» نهائياً؟";
    bootstrap.Modal.getOrCreateInstance(document.getElementById("confirmDeleteModal")).show();
}

function setupDeleteModal() {
    const modalElement = document.getElementById("confirmDeleteModal");
    const confirmButton = document.getElementById("confirmDeleteBtn");
    if (!modalElement || !confirmButton) return;

    confirmButton.addEventListener("click", () => {
        if (!pendingDelete) return;
        const { type, index } = pendingDelete;
        pendingDelete = null;

        if (type === "program") {
            tarteelPrograms.splice(index, 1);                   // remove one element from the array
            if (editingProgramIndex === index) document.getElementById("programForm").reset();
        } else {
            tarteelLectures.splice(index, 1);
            if (editingLectureIndex === index) document.getElementById("lectureForm").reset();
        }
        renumberRecords();                                      // keep the numbers without gaps
        saveTarteelData();

        // Redraw the table that changed, keeping the current search text.
        const programSearch = document.getElementById("tarteelProgramSearch");
        const lectureSearch = document.getElementById("tarteelLectureSearch");
        displayTarteelPrograms(programSearch ? programSearch.value : "");
        displayTarteelLectures(lectureSearch ? lectureSearch.value : "");
        updateAdminStats();

        bootstrap.Modal.getInstance(modalElement).hide();
        showTarteelToast("تم الحذف بنجاح.", "danger");
    });
}

/* ====================================================================
 * 6. START
 * ==================================================================== */
document.addEventListener("DOMContentLoaded", function () {
    setupAdminLogin();
    setupProgramsAdmin();
    setupLecturesAdmin();
    setupDeleteModal();
    updateAdminStats();
});
