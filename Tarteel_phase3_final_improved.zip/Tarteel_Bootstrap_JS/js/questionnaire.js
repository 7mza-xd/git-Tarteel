/*
 * Tarteel - Questionnaire page (Part III, requirement 3)
 * ------------------------------------------------------------
 * WHAT THIS FILE DOES
 *   1. Validates the form with custom rules. Four fields use DIFFERENT advanced
 *      regular expressions ("patterns"):
 *         - full name  : two or more words, each at least 2 letters (Arabic or English)
 *         - phone      : Omani mobile number, 8 digits starting with 7 or 9
 *         - e-mail     : strict address pattern (no double dots, valid domain)
 *         - comments   : 10-500 characters containing real letters
 *      The drop-down, the rating buttons and the agreement checkbox are checked
 *      too (they must be chosen / ticked).
 *   2. Shows feedback with Bootstrap classes: "is-invalid" (red + message from
 *      .invalid-feedback) and "is-valid" (green).
 *   3. Updates a progress bar that counts how many required controls are valid.
 *   4. Shows a live character counter for the comments box and a text label for
 *      the "ease of use" slider.
 *   5. When everything is valid, shows a Bootstrap modal that summarises the answers.
 */
"use strict";

document.addEventListener("DOMContentLoaded", () => {

    /* ---------------------------------------------------------------
     * 1. Page elements
     * --------------------------------------------------------------- */
    const form = document.getElementById("feedbackForm");
    const fullName = document.getElementById("fullName");
    const phone = document.getElementById("phone");
    const email = document.getElementById("email");
    const howHeard = document.getElementById("howHeard");
    const comments = document.getElementById("comments");
    const terms = document.getElementById("terms");
    const ease = document.getElementById("ease");
    const easeOutput = document.getElementById("easeOutput");
    const commentCount = document.getElementById("commentCount");
    const ratingFeedback = document.getElementById("ratingFeedback");
    const progressBar = document.getElementById("progressBar");
    const progressWrap = document.getElementById("progressWrap");
    const progressHint = document.getElementById("progressHint");

    /* ---------------------------------------------------------------
     * 2. Regular expressions (the "advanced patterns")
     * --------------------------------------------------------------- */
    // NAME: (?=.{5,60}$) is a look-ahead that limits the whole value to 5-60 characters.
    // Then: a word of 2+ Arabic/English letters, followed by one or more
    // " word" groups. So "محمد بن سالم" is accepted but "أحمد" (one word) is not.
    const namePattern = /^(?=.{5,60}$)[\u0600-\u06FFa-zA-Z]{2,}(?: [\u0600-\u06FFa-zA-Z]{2,})+$/;

    // PHONE: optional country code (+968 or 00968), then 7 or 9, then exactly 7 digits.
    // Spaces and dashes are removed before testing, so "9123 4567" works.
    const phonePattern = /^(?:\+968|00968)?[79]\d{7}$/;

    // E-MAIL: (?=.{6,254}$) limits the length; (?!.*\.\.) rejects two dots in a row;
    // then name@domain.ext where the extension has 2+ letters.
    const emailPattern = /^(?=.{6,254}$)(?!.*\.\.)[A-Za-z0-9][A-Za-z0-9._%+-]*@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;

    // COMMENTS: the look-ahead (?=.*[letters]{3}) demands at least 3 letters in a row,
    // so a message made only of digits or symbols is refused; [\s\S] allows new lines.
    const commentPattern = /^(?=[\s\S]*[\u0600-\u06FFa-zA-Z]{3})[\s\S]{10,500}$/;

    /* ---------------------------------------------------------------
     * 3. One description per required control
     *    getValue()  -> the current value (text, "" when empty)
     *    check(v)    -> "" when valid, otherwise the Arabic error message
     *    paint(msg)  -> shows red/green state with Bootstrap classes
     * --------------------------------------------------------------- */

    // Paint a normal input/select/textarea: red + message, or green.
    function paintField(field, message) {
        field.classList.toggle("is-invalid", message !== "");
        field.classList.toggle("is-valid", message === "");
        // The message box is the next ".invalid-feedback" inside the same wrapper.
        const feedback = field.parentElement.querySelector(".invalid-feedback");
        if (feedback && message !== "") feedback.textContent = message;
    }

    // The rating is a group of radio buttons: find the chosen one (or null).
    const checkedRating = () => form.querySelector('input[name="rating"]:checked');

    const controls = [
        {
            key: "fullName",
            getValue: () => fullName.value.trim(),
            check: v => namePattern.test(v) ? "" : "أدخل الاسم الثنائي على الأقل (كلمتان، كل كلمة حرفان فأكثر).",
            paint: m => paintField(fullName, m)
        },
        {
            key: "phone",
            // Remove spaces and dashes first, then test the Omani number pattern.
            getValue: () => phone.value.replace(/[\s-]/g, ""),
            check: v => phonePattern.test(v) ? "" : "رقم عماني من 8 أرقام يبدأ بـ 7 أو 9 (مثال: 91234567).",
            paint: m => paintField(phone, m)
        },
        {
            key: "email",
            getValue: () => email.value.trim(),
            check: v => emailPattern.test(v) ? "" : "صيغة البريد غير صحيحة (مثال: name@example.com).",
            paint: m => paintField(email, m)
        },
        {
            key: "howHeard",
            getValue: () => howHeard.value,
            check: v => v !== "" ? "" : "اختر إجابة من القائمة.",
            paint: m => paintField(howHeard, m)
        },
        {
            key: "rating",
            getValue: () => (checkedRating() ? checkedRating().value : ""),
            check: v => v !== "" ? "" : "اختر تقييماً واحداً.",
            // The rating has no input box, so its message uses the d-none helper class.
            paint: m => ratingFeedback.classList.toggle("d-none", m === "")
        },
        {
            key: "comments",
            getValue: () => comments.value.trim(),
            check: v => commentPattern.test(v) ? "" : "اكتب ملاحظة من 10 إلى 500 حرف تتضمن كلمات واضحة.",
            paint: m => paintField(comments, m)
        },
        {
            key: "terms",
            getValue: () => (terms.checked ? "yes" : ""),
            check: v => v !== "" ? "" : "يجب الموافقة قبل الإرسال.",
            paint: m => terms.classList.toggle("is-invalid", m !== "")
        }
    ];

    // Controls that the visitor has already visited; only those are re-checked while typing,
    // so an untouched field is not shown in red too early.
    const touched = new Set();

    // Validate ONE control, paint it, and return true when it is valid.
    function validateControl(control) {
        const message = control.check(control.getValue());
        control.paint(message);
        return message === "";
    }

    /* ---------------------------------------------------------------
     * 4. Progress bar (counts valid required controls)
     * --------------------------------------------------------------- */
    function updateProgress() {
        // Silent check: no painting, just count how many controls currently pass.
        const validCount = controls.filter(c => c.check(c.getValue()) === "").length;
        const percentage = Math.round((validCount / controls.length) * 100);

        progressBar.style.width = percentage + "%";
        progressBar.textContent = percentage + "%";
        progressWrap.setAttribute("aria-valuenow", String(percentage));

        progressHint.textContent = percentage === 100
            ? "ممتاز! جميع الحقول المطلوبة جاهزة للإرسال."
            : "أكملت " + validCount + " من " + controls.length + " حقول مطلوبة.";
    }

    /* ---------------------------------------------------------------
     * 5. Live events
     * --------------------------------------------------------------- */
    // Every control is re-checked while the visitor types or chooses, once it was visited.
    const eventMap = [
        [fullName, "input"], [phone, "input"], [email, "input"], [comments, "input"],
        [howHeard, "change"], [terms, "change"]
    ];
    eventMap.forEach(([element, eventName]) => {
        const control = controls.find(c => c.key === element.id);   // control keys match the element ids
        // "blur" marks the field as visited and checks it when the visitor leaves it.
        element.addEventListener("blur", () => { touched.add(control.key); validateControl(control); updateProgress(); });
        element.addEventListener(eventName, () => {
            if (touched.has(control.key) || element.type === "checkbox" || element.tagName === "SELECT") {
                touched.add(control.key);
                validateControl(control);
            }
            updateProgress();
        });
    });

    // Rating radio buttons: choosing one removes the error message at once.
    const ratingControl = controls.find(c => c.key === "rating");
    form.querySelectorAll('input[name="rating"]').forEach(radio => {
        radio.addEventListener("change", () => { touched.add("rating"); validateControl(ratingControl); updateProgress(); });
    });

    // Live character counter for the comments box (turns red near the 500 limit).
    comments.addEventListener("input", () => {
        const length = comments.value.length;
        commentCount.textContent = length + " / 500";
        commentCount.className = "ms-auto " + (length > 450 ? "text-danger fw-bold" : "text-success");
    });

    // Text label for the ease-of-use slider (1-5), shown in the badge beside the question.
    const easeLabels = ["", "صعب جداً", "صعب", "عادي", "سهل", "سهل جداً"];
    ease.addEventListener("input", () => {
        easeOutput.textContent = ease.value + " / 5 · " + easeLabels[Number(ease.value)];
    });

    // The "reset" button clears every red/green state and restarts the counters.
    form.addEventListener("reset", () => {
        touched.clear();
        form.querySelectorAll(".is-valid, .is-invalid").forEach(el => el.classList.remove("is-valid", "is-invalid"));
        ratingFeedback.classList.add("d-none");
        commentCount.textContent = "0 / 500";
        commentCount.className = "ms-auto text-danger";
        easeOutput.textContent = "3 / 5 · عادي";
        // Wait one tick: the browser restores the default values after the reset event.
        setTimeout(updateProgress, 0);
    });

    /* ---------------------------------------------------------------
     * 6. Submit: validate everything, then show the summary modal
     * --------------------------------------------------------------- */
    form.addEventListener("submit", event => {
        event.preventDefault();                       // never reload the page

        // Check every control (not only the first wrong one) so all errors are shown together.
        let isValid = true;
        let firstInvalid = null;
        controls.forEach(control => {
            touched.add(control.key);
            if (!validateControl(control)) {
                isValid = false;
                if (!firstInvalid) firstInvalid = control;
            }
        });
        updateProgress();

        if (!isValid) {
            // Move the keyboard focus to the first wrong field so the visitor can fix it.
            const target = firstInvalid.key === "rating" ? form.querySelector('input[name="rating"]') : document.getElementById(firstInvalid.key);
            if (target) target.focus();
            return;
        }

        // ---- Build the summary list with DOM methods (textContent keeps typed text safe) ----
        const ratingLabel = form.querySelector('label[for="' + checkedRating().id + '"]').textContent.trim();
        const likes = Array.from(form.querySelectorAll('input[name="likes"]:checked')).map(box => box.value);
        const summary = [
            ["الاسم:", fullName.value.trim()],
            ["التقييم العام:", ratingLabel],
            ["كيف عرفت ترتيل:", howHeard.value],
            ["سهولة الاستخدام:", easeOutput.textContent],
            ["أعجبني:", likes.length > 0 ? likes.join("، ") : "لم تُحدَّد"]
        ];
        const summaryList = document.getElementById("summaryList");
        summaryList.replaceChildren();
        summary.forEach(([label, value]) => {
            const dt = document.createElement("dt");
            dt.className = "col-sm-4";
            dt.textContent = label;
            const dd = document.createElement("dd");
            dd.className = "col-sm-8";
            dd.textContent = value;
            summaryList.append(dt, dd);
        });

        // Show the Bootstrap modal, then clear the form for the next visitor.
        new bootstrap.Modal(document.getElementById("thanksModal")).show();
        form.reset();
    });

    updateProgress();   // start with the correct progress text
});
