/*
 * Tarteel - Dynamic data (Part III, requirement 2)
 * ------------------------------------------------------------
 * HOW THIS FILE WORKS (short overview)
 *   1. Two constructor functions describe the two kinds of information the
 *      site keeps: TarteelProgram (a summer centre) and TarteelLecture.
 *   2. Two arrays (tarteelPrograms, tarteelLectures) are filled with real
 *      information from the site. They start from the default arrays and are
 *      remembered in the browser's localStorage, so changes made by the
 *      administrator (js/admin.js) are also what visitors see.
 *   3. Two display functions (displayTarteelPrograms / displayTarteelLectures)
 *      draw the rows of the EMPTY tables that exist in programs.html,
 *      lectures.html and admin.html. They also apply the search text.
 *        - On the public pages the tables are read-only (search only).
 *        - On admin.html the tables carry data-admin="true", so every row also
 *          gets Edit and Delete buttons (handled by js/admin.js).
 *   4. A search form on each page filters the array and redraws the table.
 * Note: localStorage is only a browser memory; PHP/MySQL replaces it in Part IV.
 */
"use strict";

/* ====================================================================
 * 1. OBJECT TYPES (constructor functions)
 * ==================================================================== */

// A program / educational centre. "this" refers to the new object being built.
function TarteelProgram(number, name, englishName, description, establishment) {
    this.number = number;               // order number shown in the first column ("01")
    this.name = name;                   // Arabic name of the centre
    this.englishName = englishName;     // optional English name
    this.description = description;     // short description
    this.establishment = establishment; // founding year / short note
}

// A lecture with its speaker, date, time and place.
function TarteelLecture(category, title, description, speaker, date, time, location, dateValue, timeValue) {
    this.category = category;       // subject + number, e.g. "العقيدة · 01"
    this.title = title;             // lecture title
    this.description = description; // short description
    this.speaker = speaker;         // lecturer name
    this.date = date;               // date as text shown in the table
    this.time = time;               // time as text shown in the table
    this.location = location;       // place of the lecture
    // The raw values of the date/time inputs ("2026-10-25", "18:00"). They let the
    // administrator's edit form show the saved date and time again.
    this.dateValue = dateValue || "";
    this.timeValue = timeValue || "";
}

/* ====================================================================
 * 2. ARRAYS INITIALISED WITH REAL INFORMATION
 * ==================================================================== */

// Default programs: the four centres that appear on the Programs page.
const defaultPrograms = [
    new TarteelProgram("01", "مركز الإمام جابر بن زيد", "Alimam Jaber Center", "هدفنا خدمة المجتمع بتعليم القرآن الكريم والعلوم الشرعية والعربية، وتنمية قدرات الأبناء بالأنشطة والمسابقات المتنوعة.", "تأسس عام 1432هـ / 2011م"),
    new TarteelProgram("02", "مركز رياض العلم", "", "مركز لتعليم القرآن الكريم وعلومه. للتواصل: 97220414", "منذ ١٤٢٥ هـ / ٢٠٠٥ م"),
    new TarteelProgram("03", "مركز الشيخ عبدالله اللزامي رحمه الله", "", "جيلٌ متعلم، عقيدةٌ ثابتة، أخلاقٌ نبوية. للاستفسار: 96876745352", "تأسس عام ١٤٢٣هـ"),
    new TarteelProgram("04", "مدرسة الشيخ حمود بن حميد الصوافي", "", "منصّة تُعنى بتوثيق حياة الشيخ المربي حمود بن حميد الصوافي -حفظه الله- ومركزه الميمون.", "منصّة توثيقية")
];

// Default lectures: the three lectures that appear on the Lectures page.
const defaultLectures = [
    new TarteelLecture("العقيدة · 01", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة", "2026-10-25", "18:00"),
    new TarteelLecture("العقيدة · 02", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة", "2026-10-25", "18:00"),
    new TarteelLecture("العقيدة · 03", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة", "2026-10-25", "18:00")
];

// Read a saved array from localStorage; if nothing is saved (or it is damaged)
// fall back to a copy of the default array. Saved plain objects are turned
// back into real objects by calling the constructor again.
function readSavedArray(key, defaults, Constructor) {
    try {
        const saved = localStorage.getItem(key);
        if (!saved) return defaults.slice();
        return JSON.parse(saved).map(item => new Constructor(...Object.values(item)));
    } catch (error) {
        console.warn("Could not read saved Tarteel data:", error);
        return defaults.slice();
    }
}

// The two live arrays that the whole site works with.
let tarteelPrograms = readSavedArray("tarteelPrograms", defaultPrograms, TarteelProgram);
let tarteelLectures = readSavedArray("tarteelLectures", defaultLectures, TarteelLecture);

// Save both arrays so that the administrator's changes are still there after reload.
function saveTarteelData() {
    try {
        localStorage.setItem("tarteelPrograms", JSON.stringify(tarteelPrograms));
        localStorage.setItem("tarteelLectures", JSON.stringify(tarteelLectures));
    } catch (error) {
        console.warn("Could not save Tarteel data:", error);
    }
}

/* ====================================================================
 * 3. TWO DISPLAY FUNCTIONS (fill the empty tables)
 * ==================================================================== */

// Add one <td> cell to a row. textContent is used (not innerHTML) so that text
// typed by an administrator is shown as plain text and can never run as HTML.
function addCell(row, value) {
    const cell = document.createElement("td");
    cell.textContent = value || "—";
    row.appendChild(cell);
}

// Add the "Edit" and "Delete" buttons cell (admin tables only).
// data-action tells js/admin.js which button was pressed; data-index is the
// position of the record inside its array.
function addActionCell(row, index) {
    const cell = document.createElement("td");
    cell.className = "text-nowrap";
    [["edit", "تعديل", "btn-outline-success"], ["delete", "حذف", "btn-outline-danger"]].forEach(([action, label, style]) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "btn btn-sm " + style + " me-1";
        button.dataset.action = action;
        button.dataset.index = String(index);
        button.textContent = label;
        cell.appendChild(button);
    });
    row.appendChild(cell);
}

// Show a single "no results" row that spans every column of the table.
function addEmptyRow(tbody, columns, text) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = columns;
    cell.className = "text-center text-secondary py-4";
    cell.textContent = text;
    row.appendChild(cell);
    tbody.appendChild(row);
}

// DISPLAY FUNCTION 1: draws the tarteelPrograms array into the programs table.
//   searchText   - only programs containing this text are shown ("" = show all)
//   highlightKey - number of a program to highlight (a row just added or edited)
function displayTarteelPrograms(searchText = "", highlightKey = null) {
    const tbody = document.getElementById("tarteelProgramsBody");
    if (!tbody) return;                       // this page has no programs table
    tbody.replaceChildren();                  // remove old rows before redrawing

    const adminMode = tbody.dataset.admin === "true";   // admin tables get Edit/Delete buttons

    // Lower-case the query so the search ignores letter case (for English text).
    const query = searchText.trim().toLocaleLowerCase();

    // Pair every program with its position in the array (index) and keep only
    // the ones whose joined text contains the query.
    const matches = tarteelPrograms
        .map((program, index) => ({ program, index }))
        .filter(({ program: p }) => [p.number, p.name, p.englishName, p.description, p.establishment]
            .join(" ").toLocaleLowerCase().includes(query));

    // One table row per matching program.
    matches.forEach(({ program: p, index }) => {
        const row = document.createElement("tr");
        if (p.number === highlightKey) row.className = "table-warning";   // changed row stands out
        [p.number, p.name, p.englishName, p.description, p.establishment]
            .forEach(value => addCell(row, value));
        if (adminMode) addActionCell(row, index);
        tbody.appendChild(row);
    });

    if (matches.length === 0) addEmptyRow(tbody, adminMode ? 6 : 5, "لا توجد برامج مطابقة لبحثك.");

    // Show "x of y" under the search box.
    const counter = document.getElementById("tarteelProgramsCount");
    if (counter) counter.textContent = "عدد النتائج: " + matches.length + " من " + tarteelPrograms.length;
}

// DISPLAY FUNCTION 2: draws the tarteelLectures array into the lectures table.
function displayTarteelLectures(searchText = "", highlightKey = null) {
    const tbody = document.getElementById("tarteelLecturesBody");
    if (!tbody) return;                       // this page has no lectures table
    tbody.replaceChildren();

    const adminMode = tbody.dataset.admin === "true";
    const query = searchText.trim().toLocaleLowerCase();

    const matches = tarteelLectures
        .map((lecture, index) => ({ lecture, index }))
        .filter(({ lecture: l }) => [l.category, l.title, l.description, l.speaker, l.date, l.time, l.location]
            .join(" ").toLocaleLowerCase().includes(query));

    matches.forEach(({ lecture: l, index }) => {
        const row = document.createElement("tr");
        if (l.category === highlightKey) row.className = "table-warning";
        [l.category, l.title, l.speaker, l.date, l.time, l.location]
            .forEach(value => addCell(row, value));
        if (adminMode) addActionCell(row, index);
        tbody.appendChild(row);
    });

    if (matches.length === 0) addEmptyRow(tbody, adminMode ? 7 : 6, "لا توجد محاضرات مطابقة لبحثك.");

    const counter = document.getElementById("tarteelLecturesCount");
    if (counter) counter.textContent = "عدد النتائج: " + matches.length + " من " + tarteelLectures.length;
}

/* ====================================================================
 * 4. SEARCH FORMS (public pages and admin page)
 * ==================================================================== */

// Connect one search form to a display function.
//   formId / inputId / clearId - ids of the form, its text box and its "clear" button
//   display - the display function to call with the typed text
function setupSearch(formId, inputId, clearId, display) {
    const form = document.getElementById(formId);
    const input = document.getElementById(inputId);
    const clear = document.getElementById(clearId);
    if (!form || !input) return;              // this page has no such search form

    // Pressing the search button (or Enter) filters the table.
    form.addEventListener("submit", event => {
        event.preventDefault();
        display(input.value);
    });
    // The table also updates while the visitor types.
    input.addEventListener("input", () => display(input.value));
    // "Clear" empties the text box and shows every row again.
    if (clear) {
        clear.addEventListener("click", () => {
            input.value = "";
            display();
        });
    }
}

// When the page is ready: draw both tables once, then connect the search forms.
// (Each function does nothing on pages that do not contain the matching table.)
document.addEventListener("DOMContentLoaded", function () {
    displayTarteelPrograms();
    displayTarteelLectures();
    setupSearch("programSearchForm", "tarteelProgramSearch", "programSearchClear", displayTarteelPrograms);
    setupSearch("lectureSearchForm", "tarteelLectureSearch", "lectureSearchClear", displayTarteelLectures);
});
