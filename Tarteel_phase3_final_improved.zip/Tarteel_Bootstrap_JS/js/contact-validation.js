/*
  Tarteel - Contact Form Validation
  ------------------------------------------------------------
  HOW IT WORKS
  The contact form uses Bootstrap's validation styles (.needs-validation and
  .was-validated). When the visitor presses "Send":
      1. three custom rules are checked with regular expressions / length tests:
            - name    : 3-50 Arabic or English letters and spaces
            - email   : a strict e-mail pattern (no double dots, valid domain)
            - message : at least 10 characters
      2. a field that breaks a rule is marked with setCustomValidity(message),
         so the browser treats it as invalid;
      3. the "subject" drop-down is checked by its HTML "required" attribute;
      4. if the form is invalid it is NOT submitted and Bootstrap shows the red
         .invalid-feedback messages; if it is valid a success toast is shown.
  This is front-end validation only; there is no server to send to yet (Part IV).
*/
"use strict";

document.addEventListener("DOMContentLoaded", function () {
    // The contact form (the only form on this page).
    const contactForm = document.querySelector("form.needs-validation");
    if (!contactForm) return;

    // The three fields that have custom rules.
    const nameField = document.getElementById("name");
    const emailField = document.getElementById("email");
    const messageField = document.getElementById("message");

    // Names: 3 to 50 Arabic or English letters and spaces only.
    const namePattern = /^[\u0600-\u06FFa-zA-Z ]{3,50}$/;
    // E-mail: the look-ahead (?!.*\.\.) rejects two dots in a row; the rest
    // requires text, "@", a domain with at least one dot, and a 2+ letter ending.
    const emailPattern = /^(?!.*\.\.)[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;

    // Runs when the visitor presses the submit button.
    contactForm.addEventListener("submit", function (event) {
        // An empty string means "valid"; any text is shown as the error message.
        nameField.setCustomValidity(namePattern.test(nameField.value.trim()) ? "" : "الاسم يجب أن يتكون من 3 إلى 50 حرفاً.");
        emailField.setCustomValidity(emailPattern.test(emailField.value.trim()) ? "" : "يرجى إدخال بريد إلكتروني صحيح.");
        messageField.setCustomValidity(messageField.value.trim().length >= 10 ? "" : "الرسالة يجب ألا تقل عن 10 أحرف.");

        // Never let the browser reload the page; there is no server yet.
        event.preventDefault();

        if (!contactForm.checkValidity()) {
            // Invalid: stop here and let Bootstrap show the red messages.
            event.stopPropagation();
            contactForm.classList.add("was-validated");
            return;
        }

        // Valid: confirm with a toast and clear the form.
        contactForm.reset();
        contactForm.classList.remove("was-validated");
        showTarteelToast("تم التحقق من رسالتك بنجاح. سيتم تفعيل الإرسال عند ربط PHP وMySQL في الجزء الرابع.");
    });

    // Remove a field's custom error as soon as the visitor edits it,
    // so a corrected field turns green on the next check.
    [nameField, emailField, messageField].forEach(function (field) {
        field.addEventListener("input", function () {
            field.setCustomValidity("");
        });
    });
});
