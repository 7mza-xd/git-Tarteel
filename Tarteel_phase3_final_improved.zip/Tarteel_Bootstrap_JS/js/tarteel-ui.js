/*
 * Tarteel - shared UI helper (Part III)
 * ------------------------------------------------------------
 * Provides one reusable function, showTarteelToast(), that displays a
 * Bootstrap "toast" (a small pop-up message) instead of the browser's
 * plain alert() box. It is loaded before the page scripts that use it.
 */
"use strict";

/**
 * Show a Bootstrap toast message at the bottom corner of the page.
 * @param {string} message - The text to show to the visitor.
 * @param {string} [type="success"] - A Bootstrap colour name:
 *        "success", "danger", "warning" ... (used as text-bg-<type>).
 */
function showTarteelToast(message, type) {
    // 1) Find the container that holds all toasts; create it the first time.
    let container = document.getElementById("tarteelToastContainer");
    if (!container) {
        container = document.createElement("div");
        container.id = "tarteelToastContainer";
        // Bootstrap classes pin the container to the bottom corner of the screen.
        container.className = "toast-container position-fixed bottom-0 start-0 p-3";
        document.body.appendChild(container);
    }

    // 2) Build the toast element (colour comes from the "type" argument).
    const toastElement = document.createElement("div");
    toastElement.className = "toast align-items-center border-0 text-bg-" + (type || "success");
    toastElement.setAttribute("role", "status");
    toastElement.setAttribute("aria-live", "polite");
    toastElement.setAttribute("aria-atomic", "true");
    toastElement.innerHTML =
        '<div class="d-flex">' +
        '<div class="toast-body fw-bold"></div>' +
        '<button type="button" class="btn-close btn-close-white m-auto ms-2" ' +
        'data-bs-dismiss="toast" aria-label="إغلاق"></button>' +
        "</div>";

    // textContent (not innerHTML) so that text typed by users can never inject HTML.
    toastElement.querySelector(".toast-body").textContent = message;
    container.appendChild(toastElement);

    // 3) Ask Bootstrap's JavaScript to show it, then remove it once it is hidden.
    const toast = new bootstrap.Toast(toastElement, { delay: 4000 });
    toastElement.addEventListener("hidden.bs.toast", function () {
        toastElement.remove();
    });
    toast.show();
}
