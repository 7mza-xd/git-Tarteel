/*
  Tarteel - Program Registration Form Validation
  ------------------------------------------------------------
  HOW IT WORKS
  There are four registration forms on programs.html, one inside each program's
  Bootstrap modal. This file finds all of them and, when a visitor presses
  "Send", it checks four fields:
      1. full name        - letters and spaces only (regular expression)
      2. Omani phone      - 8 digits starting with 7 or 9, optional +968 prefix
      3. school name      - at least 2 characters
      4. certificate file - a PDF or an image, not larger than 5 MB
  A wrong value is marked with setCustomValidity(message). Bootstrap's
  "was-validated" class then shows the red message (.invalid-feedback) or the
  green state beside each field. When everything is valid the modal is closed
  and a Bootstrap toast confirms success.
  This is front-end validation only; nothing is sent to a server yet (Part IV).
*/
"use strict";

document.addEventListener("DOMContentLoaded", function () {
    // Select all registration forms inside the program modals.
    const registrationForms = document.querySelectorAll(".registration-form");

    // Repeat the same setup for each form (one per program).
    registrationForms.forEach(function (form) {
        // The four inputs of this form, found by their name attribute.
        const nameField = form.querySelector('input[name="fullName"]');
        const phoneField = form.querySelector('input[name="phone"]');
        const schoolField = form.querySelector('input[name="school"]');
        const certificateField = form.querySelector('input[name="certificate"]');

        // Runs every time the visitor presses the submit button.
        form.addEventListener("submit", function (event) {
            // RULE 1 - name: Arabic or English letters and spaces, 3 to 60 characters.
            const namePattern = /^[\u0600-\u06FFa-zA-Z ]{3,60}$/;
            nameField.setCustomValidity(
                namePattern.test(nameField.value.trim())
                    ? ""   // empty message = the field is valid
                    : "أدخل الاسم من 3 إلى 60 حرفاً، باستخدام الحروف والمسافات فقط."
            );

            // RULE 2 - phone: optional +968, then 7 or 9, then exactly 7 more digits.
            // Spaces and dashes typed by the visitor are removed first.
            const phonePattern = /^(?:\+968)?[79][0-9]{7}$/;
            const cleanPhone = phoneField.value.replace(/[\s-]/g, "");
            phoneField.setCustomValidity(
                phonePattern.test(cleanPhone)
                    ? ""
                    : "أدخل رقم هاتف عمانياً صحيحاً مكوّناً من 8 أرقام، ويمكن إضافة +968."
            );

            // RULE 3 - school name must contain at least 2 non-space characters.
            schoolField.setCustomValidity(
                schoolField.value.trim().length >= 2
                    ? ""
                    : "يرجى إدخال اسم المدرسة بشكل صحيح."
            );

            // RULE 4 - certificate: must exist, be a PDF or image, and be <= 5 MB.
            const file = certificateField.files[0];
            let fileError = "";
            if (!file) {
                fileError = "يرجى إرفاق شهادة العام الماضي.";
            } else {
                // The type can be missing on some devices, so the extension is checked too.
                const allowedType = file.type === "application/pdf" || file.type.startsWith("image/");
                const allowedExtension = /\.(pdf|png|jpe?g|gif|webp)$/i.test(file.name);
                if (!allowedType && !allowedExtension) {
                    fileError = "يسمح بإرفاق صورة أو ملف PDF فقط.";
                } else if (file.size > 5 * 1024 * 1024) {      // 5 MB expressed in bytes
                    fileError = "حجم الملف يجب ألا يتجاوز 5 ميجابايت.";
                }
            }
            certificateField.setCustomValidity(fileError);

            // Always stop the browser's own submission; this page has no server yet.
            event.preventDefault();

            if (!form.checkValidity()) {
                // At least one field is wrong: keep the modal open and show the red messages.
                event.stopPropagation();
                form.classList.add("was-validated");
                return;
            }

            // Everything is valid: close the modal, reset the form and confirm with a toast.
            const modalElement = form.closest(".modal");
            const modal = modalElement ? bootstrap.Modal.getInstance(modalElement) : null;
            if (modal) modal.hide();
            form.reset();
            form.classList.remove("was-validated");
            showTarteelToast("تم التحقق من بيانات التسجيل بنجاح. سيتم تفعيل إرسال الطلب وحفظه عند ربط PHP وMySQL في الجزء الرابع.");
        });

        // As soon as the visitor edits a field, clear its custom error so the
        // message does not stay stuck; it is checked again on the next submit.
        [nameField, phoneField, schoolField, certificateField].forEach(function (field) {
            field.addEventListener("input", function () {
                field.setCustomValidity("");
            });
            field.addEventListener("change", function () {
                field.setCustomValidity("");
            });
        });
    });
});
