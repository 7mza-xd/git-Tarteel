
"use strict";

// ========================================
// TARTEEL FUN PAGE
// لعبة ترتيب كلمات الآيات القرآنية
// ========================================

// 1. قاعدة الأسئلة: 30 آية قرآنية
// الكلمات مخزنة بالترتيب الصحيح

const allQuestions = [

  // سورة الفاتحة
  {
    surah: "الفاتحة - الآية 2",
    words: ["الْحَمْدُ", "لِلَّهِ", "رَبِّ", "الْعَالَمِينَ"]
  },
  {
    surah: "الفاتحة - الآية 4",
    words: ["مَالِكِ", "يَوْمِ", "الدِّينِ"]
  },
  {
    surah: "الفاتحة - الآية 5",
    words: ["إِيَّاكَ", "نَعْبُدُ", "وَإِيَّاكَ", "نَسْتَعِينُ"]
  },
  {
    surah: "الفاتحة - الآية 6",
    words: ["اهْدِنَا", "الصِّرَاطَ", "الْمُسْتَقِيمَ"]
  },

  // سورة الإخلاص
  {
    surah: "الإخلاص - الآية 1",
    words: ["قُلْ", "هُوَ", "اللَّهُ", "أَحَدٌ"]
  },
  {
    surah: "الإخلاص - الآية 3",
    words: ["لَمْ", "يَلِدْ", "وَلَمْ", "يُولَدْ"]
  },
  {
    surah: "الإخلاص - الآية 4",
    words: ["وَلَمْ", "يَكُنْ", "لَهُ", "كُفُوًا", "أَحَدٌ"]
  },

  // سورة الكوثر
  {
    surah: "الكوثر - الآية 1",
    words: ["إِنَّا", "أَعْطَيْنَاكَ", "الْكَوْثَرَ"]
  },
  {
    surah: "الكوثر - الآية 2",
    words: ["فَصَلِّ", "لِرَبِّكَ", "وَانْحَرْ"]
  },
  {
    surah: "الكوثر - الآية 3",
    words: ["إِنَّ", "شَانِئَكَ", "هُوَ", "الْأَبْتَرُ"]
  },

  // سورة الشرح
  {
    surah: "الشرح - الآية 1",
    words: ["أَلَمْ", "نَشْرَحْ", "لَكَ", "صَدْرَكَ"]
  },
  {
    surah: "الشرح - الآية 4",
    words: ["وَرَفَعْنَا", "لَكَ", "ذِكْرَكَ"]
  },
  {
    surah: "الشرح - الآية 5",
    words: ["فَإِنَّ", "مَعَ", "الْعُسْرِ", "يُسْرًا"]
  },
  {
    surah: "الشرح - الآية 7",
    words: ["فَإِذَا", "فَرَغْتَ", "فَانْصَبْ"]
  },
  {
    surah: "الشرح - الآية 8",
    words: ["وَإِلَىٰ", "رَبِّكَ", "فَارْغَبْ"]
  },

  // سورة الناس
  {
    surah: "الناس - الآية 1",
    words: ["قُلْ", "أَعُوذُ", "بِرَبِّ", "النَّاسِ"]
  },
  {
    surah: "الناس - الآية 4",
    words: ["مِنْ", "شَرِّ", "الْوَسْوَاسِ", "الْخَنَّاسِ"]
  },

  // سورة الفلق
  {
    surah: "الفلق - الآية 1",
    words: ["قُلْ", "أَعُوذُ", "بِرَبِّ", "الْفَلَقِ"]
  },
  {
    surah: "الفلق - الآية 2",
    words: ["مِنْ", "شَرِّ", "مَا", "خَلَقَ"]
  },

  // سورة العصر
  {
    surah: "العصر - الآية 2",
    words: ["إِنَّ", "الْإِنْسَانَ", "لَفِي", "خُسْرٍ"]
  },

  // سورة طه
  {
    surah: "طه - الآية 25",
    words: ["قَالَ", "رَبِّ", "اشْرَحْ", "لِي", "صَدْرِي"]
  },
  {
    surah: "طه - الآية 26",
    words: ["وَيَسِّرْ", "لِي", "أَمْرِي"]
  },
  {
    surah: "طه - الآية 114",
    words: ["وَقُلْ", "رَبِّ", "زِدْنِي", "عِلْمًا"]
  },

  // سورة البقرة
  {
    surah: "البقرة - الآية 2",
    words: ["ذَٰلِكَ", "الْكِتَابُ", "لَا", "رَيْبَ", "فِيهِ", "هُدًى", "لِلْمُتَّقِينَ"]
  },

  // سورة الرحمن
  {
    surah: "الرحمن - الآية 13",
    words: ["فَبِأَيِّ", "آلَاءِ", "رَبِّكُمَا", "تُكَذِّبَانِ"]
  },

  // سورة الفيل
  {
    surah: "الفيل - الآية 2",
    words: ["أَلَمْ", "يَجْعَلْ", "كَيْدَهُمْ", "فِي", "تَضْلِيلٍ"]
  },

  // سورة الزلزلة
  {
    surah: "الزلزلة - الآية 1",
    words: ["إِذَا", "زُلْزِلَتِ", "الْأَرْضُ", "زِلْزَالَهَا"]
  },

  // سورة النصر
  {
    surah: "النصر - الآية 1",
    words: ["إِذَا", "جَاءَ", "نَصْرُ", "اللَّهِ", "وَالْفَتْحُ"]
  },

  // سورة قريش
  {
    surah: "قريش - الآية 3",
    words: ["فَلْيَعْبُدُوا", "رَبَّ", "هَٰذَا", "الْبَيْتِ"]
  },

  // سورة المسد
  {
    surah: "المسد - الآية 1",
    words: ["تَبَّتْ", "يَدَا", "أَبِي", "لَهَبٍ", "وَتَبَّ"]
  }

];

// ========================================
// 2. اختيار ثلاثة أسئلة عشوائية
// ========================================

// خلط المصفوفة باستخدام Fisher-Yates
function shuffleArray(array) {

  const result = [...array];

  for (let i = result.length - 1; i > 0; i--) {

    const j = Math.floor(Math.random() * (i + 1));

    [result[i], result[j]] =
      [result[j], result[i]];
  }

  return result;
}

// اختيار ثلاث آيات مختلفة
function getRandomQuestions() {

  return shuffleArray(allQuestions).slice(0, 3);
}

// أسئلة الجولة الحالية
let questions = getRandomQuestions();

// ========================================
// 3. متغيرات اللعبة
// ========================================

let questionIndex = 0;
let score = 0;
let selectedIndices = [];
let locked = false;
let order = [];

// الوصول إلى عناصر HTML باستخدام ID
const $ = id => document.getElementById(id);

// ========================================
// 4. خلط كلمات الآية
// ========================================

function shuffleIndices(length) {

  const values = Array.from(
    { length },
    (_, i) => i
  );

  // خلط ترتيب الكلمات
  for (let i = values.length - 1; i > 0; i--) {

    const j = Math.floor(Math.random() * (i + 1));

    [values[i], values[j]] =
      [values[j], values[i]];
  }

  // التأكد من عدم ظهور الكلمات مرتبة
  if (
    length > 1 &&
    values.every((value, i) => value === i)
  ) {
    [values[0], values[1]] =
      [values[1], values[0]];
  }

  return values;
}

// ========================================
// 5. عرض الكلمات داخل الصفحة
// ========================================

function renderWords() {

  const question = questions[questionIndex];

  const answer = $("answer");
  const choices = $("choices");

  // إزالة الكلمات القديمة
  answer.replaceChildren();
  choices.replaceChildren();

  // إظهار رسالة قبل اختيار الكلمات
  if (selectedIndices.length === 0) {

    const placeholder = document.createElement("span");

    placeholder.className = "text-secondary";

    placeholder.textContent =
      "اختر الكلمات بالترتيب الصحيح";

    answer.appendChild(placeholder);
  }

  // عرض الكلمات التي اختارها المستخدم
  selectedIndices.forEach((wordIndex, position) => {

    const button = document.createElement("button");

    button.type = "button";

    button.className =
      "btn btn-success rounded-pill m-1";

    button.textContent =
      question.words[wordIndex];

    button.disabled = locked;

    // السماح بإزالة الكلمة عند الضغط عليها
    button.addEventListener("click", function () {

      if (locked) return;

      selectedIndices.splice(position, 1);

      renderWords();
    });

    answer.appendChild(button);
  });

  // عرض الكلمات المتبقية
  order
    .filter(index => !selectedIndices.includes(index))
    .forEach(wordIndex => {

      const button = document.createElement("button");

      button.type = "button";

      button.className =
        "btn btn-outline-success rounded-pill m-1 px-4";

      button.textContent =
        question.words[wordIndex];

      button.disabled = locked;

      // إضافة الكلمة عند الضغط عليها
      button.addEventListener("click", function () {

        if (locked) return;

        selectedIndices.push(wordIndex);

        renderWords();
      });

      choices.appendChild(button);
    });

  // تفعيل زر التحقق عند اكتمال الكلمات
  $("checkBtn").disabled =
    locked ||
    selectedIndices.length !== question.words.length;

  // تفعيل زر المسح عند وجود كلمات مختارة
  $("clearBtn").disabled =
    locked || selectedIndices.length === 0;
}

// ========================================
// 6. عرض السؤال الحالي
// ========================================

function showQuestion() {

  locked = false;

  selectedIndices = [];

  // خلط كلمات الآية الجديدة
  order = shuffleIndices(
    questions[questionIndex].words.length
  );

  // عرض اسم السورة
  $("surah").textContent =
    "سورة " + questions[questionIndex].surah;

  // عرض رقم السؤال
  $("questionNumber").textContent =
    `السؤال ${questionIndex + 1} من ${questions.length}`;

  // تحديث النقاط
  $("score").textContent = score;

  // حساب نسبة التقدم
  const progressValue =
    (questionIndex / questions.length) * 100;

  $("progress").style.width =
    progressValue + "%";

  $("progress").setAttribute(
    "aria-valuenow",
    String(progressValue)
  );

  // إخفاء رسالة النتيجة
  $("feedback").className =
    "alert d-none mt-3";

  // إخفاء زر السؤال التالي
  $("nextBtn").classList.add("d-none");

  // إظهار لوحة اللعبة
  $("gamePanel").classList.remove("d-none");

  // إخفاء لوحة النتيجة النهائية
  $("finishPanel").classList.add("d-none");

  // عرض الكلمات
  renderWords();
}

// ========================================
// 7. التحقق من الإجابة
// ========================================

function checkAnswer() {

  // التأكد من اختيار جميع الكلمات
  if (
    locked ||
    selectedIndices.length !==
      questions[questionIndex].words.length
  ) {
    return;
  }

  // منع تعديل الإجابة بعد التحقق
  locked = true;

  // مقارنة ترتيب الكلمات
  const correct = selectedIndices.every(
    (wordIndex, i) => wordIndex === i
  );

  // إضافة النقاط عند الإجابة الصحيحة
  if (correct) {
    score += 10;
  }

  // تحديث النقاط
  $("score").textContent = score;

  // إظهار رسالة النتيجة
  $("feedback").className =
    correct
      ? "alert alert-success mt-3"
      : "alert alert-warning mt-3";

  if (correct) {

    $("feedback").textContent =
      "أحسنت! ترتيب الآية صحيح، حصلت على 10 نقاط.";

  } else {

    $("feedback").textContent =
      "الترتيب غير صحيح. الترتيب الصحيح: " +
      questions[questionIndex].words.join(" ");
  }

  // تغيير نص الزر حسب السؤال
  $("nextBtn").textContent =
    questionIndex === questions.length - 1
      ? "عرض النتيجة"
      : "السؤال التالي";

  // إظهار زر الانتقال
  $("nextBtn").classList.remove("d-none");

  renderWords();
}

// ========================================
// 8. الانتقال إلى السؤال التالي
// ========================================

function nextQuestion() {

  if (!locked) return;

  questionIndex++;

  // إذا بقيت أسئلة
  if (questionIndex < questions.length) {

    showQuestion();

  } else {

    // إخفاء اللعبة
    $("gamePanel").classList.add("d-none");

    // إظهار النتيجة النهائية
    $("finishPanel").classList.remove("d-none");

    // عرض النقاط
    $("finalScore").textContent =
      `${score} من ${questions.length * 10}`;

    // عرض رسالة تشجيعية
    if (score === questions.length * 10) {

      $("finalMessage").textContent =
        "ممتاز! أجبت عن جميع الأسئلة بشكل صحيح.";

    } else if (score >= 20) {

      $("finalMessage").textContent =
        "أحسنت! نتيجة رائعة، استمر في التعلم.";

    } else {

      $("finalMessage").textContent =
        "محاولة جيدة! العب مرة أخرى لتحسين نتيجتك.";
    }

    // إكمال شريط التقدم
    $("progress").style.width = "100%";

    $("progress").setAttribute(
      "aria-valuenow",
      "100"
    );
  }
}

// ========================================
// 9. إعادة تشغيل اللعبة
// ========================================

function restartGame() {

  // اختيار 3 آيات عشوائية جديدة
  questions = getRandomQuestions();

  // تصفير رقم السؤال
  questionIndex = 0;

  // تصفير النقاط
  score = 0;

  // إعادة عرض اللعبة
  showQuestion();
}

// ========================================
// 10. ربط الأزرار بالأحداث
// ========================================

// زر التحقق من الإجابة
$("checkBtn").addEventListener(
  "click",
  checkAnswer
);

// زر مسح الإجابة
$("clearBtn").addEventListener("click", function () {

  if (!locked) {

    selectedIndices = [];

    renderWords();
  }
});

// زر السؤال التالي
$("nextBtn").addEventListener(
  "click",
  nextQuestion
);

// زر إعادة اللعب
$("restartBtn").addEventListener(
  "click",
  restartGame
);

// ========================================
// 11. بدء اللعبة
// ========================================

showQuestion();
