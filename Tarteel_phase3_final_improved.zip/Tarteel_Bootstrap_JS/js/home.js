/*
  Tarteel - Homepage JavaScript (Part III, requirement 6)
  ------------------------------------------------------------
  HOW THIS FILE WORKS
    1. createTarteelGallery()      builds a photo gallery section above the footer.
    2. createTarteelWelcomeBanner() builds a moving text banner at the very bottom
                                    of the page (after the footer).
    3. updateTarteelDateTime()      writes today's date and the current time inside
                                    the banner; it is called again every second.
    4. showNextTarteelImage()       swaps the gallery photo every 3 seconds
                                    (setInterval), using Bootstrap's "fade" class
                                    for a smooth change.
  Everything starts after the HTML page has finished loading (DOMContentLoaded).
*/
"use strict";

// The photos of the slideshow: file, alternative text (for screen readers) and caption.
const tarteelGallery = [
    { src: "images/gallery-1.png", alt: "مصحف مفتوح", caption: "رحلة تعلم وتدبر" },
    { src: "images/gallery-2.png", alt: "مسجد وقت الغروب", caption: "مجالس علم وسكينة" },
    { src: "images/gallery-3.png", alt: "مكتبة وكتب علمية", caption: "العلم نور وهداية" }
];

// Index (0, 1, 2) of the photo that is on the screen now.
let tarteelGalleryIndex = 0;

// How long each photo stays on the screen, in milliseconds (3000 ms = 3 seconds).
const GALLERY_DELAY = 3000;

/* ------------------------------------------------------------------
 * Welcome banner: text that moves across the bottom of the page.
 * ------------------------------------------------------------------ */
function createTarteelWelcomeBanner() {
    const footer = document.querySelector("footer");
    // Stop if there is no footer, or if the banner already exists (avoid duplicates).
    if (!footer || document.getElementById("tarteelWelcomeBanner")) return;

    // Outer box of the banner.
    const banner = document.createElement("div");
    banner.id = "tarteelWelcomeBanner";
    banner.setAttribute("role", "marquee");
    banner.setAttribute("aria-label", "رسالة الترحيب والتاريخ والوقت");

    // The moving track that holds the text and is animated from right to left.
    const movingText = document.createElement("div");
    movingText.id = "tarteelMovingTrack";

    // Part 1 of the message: the welcome sentence with the website name.
    const welcomeText = document.createElement("span");
    welcomeText.textContent = "أهلاً بكم في منصة ترتيل 🌿  |  ";

    // Part 2 of the message: date and time, filled by updateTarteelDateTime().
    const dateTime = document.createElement("span");
    dateTime.id = "tarteelCurrentDateTime";

    movingText.append(welcomeText, dateTime);
    banner.appendChild(movingText);

    // The movement is a CSS animation ("marquee") that slides the track from
    // the right edge of the screen to the left edge and then starts again.
    const style = document.createElement("style");
    style.textContent = `
        #tarteelWelcomeBanner {
            width: 100%;
            height: 80px;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            background: #075342;
            color: #ffffff;
            direction: ltr;
            white-space: nowrap;
            border-top: 1px solid rgba(255, 255, 255, .25);
        }
        #tarteelMovingTrack {
            position: absolute;
            left: 0;
            width: max-content;
            display: inline-block;
            color: #ffffff;
            font-family: inherit;
            font-size: 24px;
            font-weight: 700;
            line-height: 1.5;
            white-space: nowrap;
            will-change: transform;
            animation: tarteelFullMarquee 22s linear infinite;
        }
        @keyframes tarteelFullMarquee {
            from { transform: translateX(100vw); }
            to { transform: translateX(-100%); }
        }
        @media (max-width: 576px) {
            #tarteelMovingTrack { font-size: 19px; animation-duration: 25s; }
        }
        /* People who asked their device to avoid motion see a still, centred message. */
        @media (prefers-reduced-motion: reduce) {
            #tarteelMovingTrack {
                position: static;
                width: 100%;
                text-align: center;
                white-space: normal;
                animation: none;
            }
            #tarteelWelcomeBanner { height: auto; min-height: 80px; padding: 12px; }
        }
    `;
    document.head.appendChild(style);

    // Put the banner AFTER the footer so it is the last thing at the bottom of the page.
    footer.insertAdjacentElement("afterend", banner);
}

/* ------------------------------------------------------------------
 * Photo gallery (rotating slideshow)
 * ------------------------------------------------------------------ */
function createTarteelGallery() {
    const footer = document.querySelector("footer");
    if (!footer || document.getElementById("tarteelGallerySection")) return;

    // Section that holds the title, the photo and its caption.
    const section = document.createElement("section");
    section.className = "container py-4 text-center";
    section.id = "tarteelGallerySection";

    const heading = document.createElement("h2");
    heading.className = "h3 fw-bold text-success mb-3";
    heading.textContent = "معرض ترتيل";

    // The photo starts with the first image of the array. Bootstrap's "fade show"
    // classes give a smooth opacity change when the photo is replaced.
    const image = document.createElement("img");
    image.id = "tarteelGalleryImage";
    image.src = tarteelGallery[0].src;
    image.alt = tarteelGallery[0].alt;
    image.className = "img-fluid rounded-4 shadow fade show";
    image.style.maxHeight = "380px";
    image.style.width = "100%";
    image.style.objectFit = "cover";

    const caption = document.createElement("p");
    caption.id = "tarteelGalleryCaption";
    caption.className = "mt-3 fw-bold text-success";
    caption.textContent = tarteelGallery[0].caption;

    section.append(heading, image, caption);
    footer.parentNode.insertBefore(section, footer);   // place it immediately above the footer
}

// Move to the next photo; after the last one (index 2) go back to the first (index 0).
function showNextTarteelImage() {
    // The % (remainder) operator wraps the index: (2 + 1) % 3 = 0.
    tarteelGalleryIndex = (tarteelGalleryIndex + 1) % tarteelGallery.length;
    const next = tarteelGallery[tarteelGalleryIndex];

    const image = document.getElementById("tarteelGalleryImage");
    const caption = document.getElementById("tarteelGalleryCaption");
    if (!image || !caption) return;

    // 1) fade the old photo out, 2) swap the picture and caption, 3) fade the new one in.
    image.classList.remove("show");
    setTimeout(function () {
        image.src = next.src;
        image.alt = next.alt;
        caption.textContent = next.caption;
        image.classList.add("show");
    }, 250);
}

/* ------------------------------------------------------------------
 * Live date and time inside the banner
 * ------------------------------------------------------------------ */
function updateTarteelDateTime() {
    const output = document.getElementById("tarteelCurrentDateTime");
    if (!output) return;

    const now = new Date();   // the computer's current date and time

    // Format the date and time in Arabic (Oman).
    const date = now.toLocaleDateString("ar-OM", { year: "numeric", month: "long", day: "numeric" });
    const time = now.toLocaleTimeString("ar-OM", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

    output.textContent = "اليوم: " + date + "  |  الوقت الآن: " + time;
}

/* ------------------------------------------------------------------
 * Start everything when the page is ready
 * ------------------------------------------------------------------ */
document.addEventListener("DOMContentLoaded", function () {
    createTarteelGallery();
    createTarteelWelcomeBanner();
    updateTarteelDateTime();                              // show the time immediately

    setInterval(updateTarteelDateTime, 1000);             // refresh the clock every second
    setInterval(showNextTarteelImage, GALLERY_DELAY);     // change the photo every 3 seconds
});
