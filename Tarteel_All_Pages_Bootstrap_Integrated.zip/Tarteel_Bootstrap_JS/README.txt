مشروع ترتيل - نسخة Bootstrap RTL
- افتح index.html لتشغيل الموقع.
- جميع الصفحات تستخدم Bootstrap 5.3.3 RTL عبر CDN، وتحتاج اتصالاً بالإنترنت لتحميل Bootstrap والخط.
- تم الحفاظ على اتجاه RTL وثيم ترتيل: الأخضر #075342 والبرتقالي #D47233 والخلفية #F8F5EF.
- تم تحويل الصفحات إلى Bootstrap components وutility classes؛ يوجد CSS محدود جداً للخط والألوان فقط.
- النماذج واللوحة أمثلة Front-End. لا يتم حفظ الطلبات أو قرارات الإدارة دون Backend وقاعدة بيانات.
- أسماء الصفحات: index.html, programs.html, lectures.html, about-us.html, contact-us.html, admin.html
