/*
  Tarteel - Program Registration Form Validation
  This file validates the four registration forms shown in the program modals.
  It checks the applicant's name, Omani phone number, school name, and certificate file.
  Bootstrap's was-validated class is used to display clear feedback beside invalid fields.
  This is front-end validation only; it does not send or save registration data.
*/
document.addEventListener("DOMContentLoaded", function () {
    // Select all registration forms inside the program modals.
    const registrationForms = document.querySelectorAll(".registration-form");

    registrationForms.forEach(function (form) {
        const nameField = form.querySelector('input[name="fullName"]');
        const phoneField = form.querySelector('input[name="phone"]');
        const schoolField = form.querySelector('input[name="school"]');
        const certificateField = form.querySelector('input[name="certificate"]');

        form.addEventListener("submit", function (event) {
            // Allow Arabic or English letters and spaces; require at least 3 characters.
            const namePattern = /^[\u0600-\u06FFa-zA-Z ]{3,60}$/;
            nameField.setCustomValidity(
                namePattern.test(nameField.value.trim())
                    ? ""
                    : "أدخل الاسم من 3 إلى 60 حرفاً، باستخدام الحروف والمسافات فقط."
            );

            // Accept an Omani mobile number with 8 digits, optionally prefixed by +968.
            const phonePattern = /^(?:\+968)?[79][0-9]{7}$/;
            const cleanPhone = phoneField.value.replace(/[\s-]/g, "");
            phoneField.setCustomValidity(
                phonePattern.test(cleanPhone)
                    ? ""
                    : "أدخل رقم هاتف عمانياً صحيحاً مكوّناً من 8 أرقام، ويمكن إضافة +968."
            );

            // School name must contain at least 2 non-space characters.
            schoolField.setCustomValidity(
                schoolField.value.trim().length >= 2
                    ? ""
                    : "يرجى إدخال اسم المدرسة بشكل صحيح."
            );

            // Require a PDF or image certificate and limit its size to 5 MB.
            const file = certificateField.files[0];
            let fileError = "";
            if (!file) {
                fileError = "يرجى إرفاق شهادة العام الماضي.";
            } else {
                const allowedType = file.type === "application/pdf" || file.type.startsWith("image/");
                const allowedExtension = /\.(pdf|png|jpe?g|gif|webp)$/i.test(file.name);
                if (!allowedType && !allowedExtension) {
                    fileError = "يسمح بإرفاق صورة أو ملف PDF فقط.";
                } else if (file.size > 5 * 1024 * 1024) {
                    fileError = "حجم الملف يجب ألا يتجاوز 5 ميجابايت.";
                }
            }
            certificateField.setCustomValidity(fileError);

            // Stop submission if any field is invalid and show Bootstrap validation styles.
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            } else {
                // No backend is connected yet, so only show a successful validation message.
                event.preventDefault();
                alert("تم التحقق من بيانات التسجيل بنجاح. سيتم تفعيل إرسال الطلب وحفظه عند ربط PHP وMySQL في الجزء الرابع.");
                form.reset();
                form.classList.remove("was-validated");
            }

            form.classList.add("was-validated");
        });

        // Clear custom validation messages when the user edits a field.
        [nameField, phoneField, schoolField, certificateField].forEach(function (field) {
            field.addEventListener("input", function () {
                field.setCustomValidity("");
            });
            field.addEventListener("change", function () {
                field.setCustomValidity("");
            });
        });
    });
});
