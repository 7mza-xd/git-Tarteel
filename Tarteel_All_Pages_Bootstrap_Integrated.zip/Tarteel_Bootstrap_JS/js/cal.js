
"use strict";

// حاسبة زكاة المال - ترتيل

// نصاب الذهب = 85 جرامًا من الذهب الخالص
const GOLD_NISAB = 85;

// نسبة الزكاة = 2.5%
const ZAKAT_RATE = 0.025;

// عناصر الصفحة
const goldInput = document.getElementById("goldPrice");
const moneyInput = document.getElementById("money");

const nisabResult = document.getElementById("nisabResult");
const zakatResult = document.getElementById("zakatResult");
const message = document.getElementById("message");
const resetBtn = document.getElementById("resetBtn");

// تنسيق المبلغ بالريال العماني
function formatMoney(number) {
  return number.toFixed(3) + " ر.ع";
}

// حساب النصاب والزكاة تلقائيًا
function calculateZakat() {

  const goldText = goldInput.value.trim();
  const moneyText = moneyInput.value.trim();

  const goldPrice = Number(goldText);
  const money = Number(moneyText);

  // التحقق من سعر الذهب
  if (
    goldText === "" ||
    !Number.isFinite(goldPrice) ||
    goldPrice <= 0
  ) {

    nisabResult.textContent = formatMoney(0);
    zakatResult.textContent = formatMoney(0);

    message.textContent =
      "أدخل سعر جرام الذهب أولًا";

    return;
  }

  // حساب النصاب
  const nisab = goldPrice * GOLD_NISAB;

  // عرض النصاب فورًا
  nisabResult.textContent = formatMoney(nisab);

  // التحقق من المبلغ
  if (
    moneyText === "" ||
    !Number.isFinite(money) ||
    money < 0
  ) {

    zakatResult.textContent = formatMoney(0);

    message.textContent =
      "أدخل المبلغ الذي تملكه";

    return;
  }

  // إذا بلغ المبلغ النصاب
  if (money >= nisab) {

    const zakat = money * ZAKAT_RATE;

    zakatResult.textContent =
      formatMoney(zakat);

    message.className = "text-success mb-0";

    message.textContent =
      "بلغ المبلغ النصاب. الزكاة المعروضة بافتراض اكتمال الحول.";

  } else {

    // إذا كان المبلغ أقل من النصاب
    zakatResult.textContent = formatMoney(0);

    message.className = "text-warning mb-0";

    message.textContent =
      "المبلغ أقل من النصاب، فلا تجب الزكاة وفق هذا الحساب.";
  }
}

// تحديث الحساب مباشرة عند إدخال سعر الذهب
goldInput.addEventListener("input", calculateZakat);

// تحديث الحساب مباشرة عند إدخال المبلغ
moneyInput.addEventListener("input", calculateZakat);

// مسح جميع البيانات
resetBtn.addEventListener("click", function() {

  goldInput.value = "";
  moneyInput.value = "";

  nisabResult.textContent = formatMoney(0);
  zakatResult.textContent = formatMoney(0);

  message.className = "text-secondary mb-0";
  message.textContent = "أدخل سعر الذهب والمبلغ";

});

// تشغيل الحاسبة عند فتح الصفحة
calculateZakat();
