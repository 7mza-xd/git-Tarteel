/**
 * Questionnaire Form Validation and Interactive Progress
 * Validates inputs using Advanced Regular Expressions (Patterns).
 */

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("feedbackForm");
    const fullName = document.getElementById("fullName");
    const phone = document.getElementById("phone");
    const email = document.getElementById("email");
    const comments = document.getElementById("comments");
    const commentCount = document.getElementById("commentCount");
    
    const progressBar = document.getElementById("progressBar");
    const progressWrap = document.getElementById("progressWrap");

    // Regular Expressions for advanced validation
    // Name: Must contain Arabic or English letters and have at least two words (First and Last name)
    const namePattern = /^[\u0600-\u06FFa-zA-Z]{3,}(?: [\u0600-\u06FFa-zA-Z]{3,})+$/;
    
    // Phone: Must be an Omani number starting with 9 or 7, followed by exactly 7 digits
    const phonePattern = /^(9|7)\d{7}$/;
    
    // Email: Advanced standard email pattern validation
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    // Live character count for Textarea
    comments.addEventListener("input", () => {
        const currentLength = comments.value.length;
        commentCount.innerText = `${currentLength} / 500`;
        if(currentLength > 450) {
            commentCount.classList.replace("text-success", "text-danger");
        } else {
            commentCount.classList.add("text-success");
        }
        updateProgress();
    });

    // Inputs listener to update the progress bar dynamically
    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('change', updateProgress);
    });

    function updateProgress() {
        let filled = 0;
        const totalRequired = form.querySelectorAll('[required]').length;
        
        form.querySelectorAll('[required]').forEach(field => {
            if (field.type === 'radio' || field.type === 'checkbox') {
                if (form.querySelector(`[name="${field.name}"]:checked`)) filled++;
            } else if (field.value.trim() !== '') {
                filled++;
            }
        });

        // Some radio buttons share the same name, adjust the count
        const uniqueRequired = 6; // Adjusted for this specific form logic
        let percentage = Math.min(Math.round((filled / uniqueRequired) * 100), 100);
        
        progressBar.style.width = percentage + '%';
        progressBar.innerText = percentage + '%';
        progressWrap.setAttribute('aria-valuenow', percentage);
    }

    // Form Submit Event Validation
    form.addEventListener("submit", (event) => {
        event.preventDefault(); // Stop default submission
        let isValid = true;

        // 1. Validate Full Name
        if (!namePattern.test(fullName.value.trim())) {
            fullName.classList.add("is-invalid");
            fullName.classList.remove("is-valid");
            document.getElementById("fullNameFeedback").innerText = "يرجى إدخال الاسم الثنائي على الأقل بحروف صحيحة.";
            isValid = false;
        } else {
            fullName.classList.add("is-valid");
            fullName.classList.remove("is-invalid");
        }

        // 2. Validate Phone (Omani format)
        if (!phonePattern.test(phone.value.trim())) {
            phone.classList.add("is-invalid");
            phone.classList.remove("is-valid");
            document.getElementById("phoneFeedback").innerText = "يجب أن يبدأ الرقم العماني بـ 7 أو 9 ويتكون من 8 أرقام.";
            isValid = false;
        } else {
            phone.classList.add("is-valid");
            phone.classList.remove("is-invalid");
        }

        // 3. Validate Email
        if (!emailPattern.test(email.value.trim())) {
            email.classList.add("is-invalid");
            email.classList.remove("is-valid");
            document.getElementById("emailFeedback").innerText = "صيغة البريد الإلكتروني غير صحيحة.";
            isValid = false;
        } else {
            email.classList.add("is-valid");
            email.classList.remove("is-invalid");
        }

        // If all validation rules pass, trigger the Bootstrap Modal
        if (isValid) {
            const summaryList = document.getElementById("summaryList");
            summaryList.innerHTML = `
                <dt class="col-sm-4">الاسم:</dt><dd class="col-sm-8">${fullName.value}</dd>
                <dt class="col-sm-4">التقييم:</dt><dd class="col-sm-8">${form.querySelector('input[name="rating"]:checked').value} / 4</dd>
            `;
            const thanksModal = new bootstrap.Modal(document.getElementById('thanksModal'));
            thanksModal.show();
            form.reset();
            updateProgress();
        }
    });
});