/*
 * Tarteel - JavaScript dynamic data management (Part III)
 * The public Programs and Lectures pages display data from two arrays.
 * Only admin.html receives the add forms. Data is stored in localStorage
 * for this JavaScript-only phase; PHP/MySQL will replace it in Part IV.
 */

// Constructor for a program/educational centre.
function TarteelProgram(number, name, englishName, description, establishment) {
    this.number = number;
    this.name = name;
    this.englishName = englishName;
    this.description = description;
    this.establishment = establishment;
}

// Constructor for a lecture.
function TarteelLecture(category, title, description, speaker, date, time, location) {
    this.category = category;
    this.title = title;
    this.description = description;
    this.speaker = speaker;
    this.date = date;
    this.time = time;
    this.location = location;
}

// Initial sample data taken from the existing website content.
const defaultPrograms = [
    new TarteelProgram("01", "مركز الإمام جابر بن زيد", "Alimam Jaber Center", "هدفنا خدمة المجتمع بتعليم القرآن الكريم والعلوم الشرعية والعربية، وتنمية قدرات الأبناء بالأنشطة والمسابقات المتنوعة.", "تأسس عام 1432هـ / 2011م"),
    new TarteelProgram("02", "مركز رياض العلم", "", "مركز لتعليم القرآن الكريم وعلومه. للتواصل: 97220414", "منذ ١٤٢٥ هـ / ٢٠٠٥ م"),
    new TarteelProgram("03", "مركز الشيخ عبدالله اللزامي رحمه الله", "", "جيلٌ متعلم، عقيدةٌ ثابتة، أخلاقٌ نبوية. للاستفسار: 96876745352", "تأسس عام ١٤٢٣هـ"),
    new TarteelProgram("04", "مدرسة الشيخ حمود بن حميد الصوافي", "", "منصّة تُعنى بتوثيق حياة الشيخ المربي حمود بن حميد الصوافي -حفظه الله- ومركزه الميمون.", "منصّة توثيقية")
];

const defaultLectures = [
    new TarteelLecture("العقيدة · 01", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة"),
    new TarteelLecture("العقيدة · 02", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة"),
    new TarteelLecture("العقيدة · 03", "مبادئ العقيدة الإسلامية", "التعرّف على أساسيات العقيدة الإسلامية وأهميتها في حياة المسلم.", "أحمد محمد", "25 أكتوبر 2026", "6:00 مساءً", "مسجد قريب من الجامعة")
];

// Read saved browser data; if none exists, use the initial sample arrays.
function readSavedArray(key, defaults, Constructor) {
    try {
        const saved = localStorage.getItem(key);
        if (!saved) return defaults.slice();
        return JSON.parse(saved).map(item => new Constructor(...Object.values(item)));
    } catch (error) {
        console.warn("Could not read saved Tarteel data:", error);
        return defaults.slice();
    }
}

let tarteelPrograms = readSavedArray("tarteelPrograms", defaultPrograms, TarteelProgram);
let tarteelLectures = readSavedArray("tarteelLectures", defaultLectures, TarteelLecture);

function saveTarteelData() {
    localStorage.setItem("tarteelPrograms", JSON.stringify(tarteelPrograms));
    localStorage.setItem("tarteelLectures", JSON.stringify(tarteelLectures));
}

// Add a cell safely using textContent rather than inserting user text as HTML.
function addCell(row, value) {
    const cell = document.createElement("td");
    cell.textContent = value || "—";
    row.appendChild(cell);
}

// Render the programs array into the table on programs.html.
function displayTarteelPrograms(searchText = "") {
    const tbody = document.getElementById("tarteelProgramsBody");
    if (!tbody) return;
    tbody.replaceChildren();
    const query = searchText.trim().toLocaleLowerCase();
    tarteelPrograms.filter(p => [p.name, p.englishName, p.description, p.establishment].join(" ").toLocaleLowerCase().includes(query))
        .forEach(p => {
            const row = document.createElement("tr");
            [p.number, p.name, p.englishName, p.description, p.establishment].forEach(value => addCell(row, value));
            tbody.appendChild(row);
        });
}

// Render the lectures array into the table on lectures.html.
function displayTarteelLectures(searchText = "") {
    const tbody = document.getElementById("tarteelLecturesBody");
    if (!tbody) return;
    tbody.replaceChildren();
    const query = searchText.trim().toLocaleLowerCase();
    tarteelLectures.filter(l => [l.category, l.title, l.description, l.speaker, l.date, l.time, l.location].join(" ").toLocaleLowerCase().includes(query))
        .forEach(l => {
            const row = document.createElement("tr");
            [l.category, l.title, l.speaker, l.date, l.time, l.location].forEach(value => addCell(row, value));
            tbody.appendChild(row);
        });
}

// Replace the existing program cards with a real search field and an empty table.
function setupProgramsPage() {
    const main = document.querySelector("main");
    const oldCards = main && main.querySelector(":scope > .row.g-4");
    if (!main || !oldCards) return;
    const section = document.createElement("section");
    section.className = "mt-4";
    section.innerHTML = `
      <div class="mb-3"><label class="form-label fw-bold" for="tarteelProgramSearch">البحث في البرامج</label>
      <input id="tarteelProgramSearch" class="form-control" type="search" placeholder="ابحث باسم البرنامج أو الوصف"></div>
      <div class="table-responsive"><table class="table table-striped table-bordered align-middle">
        <thead class="table-success"><tr><th>الرقم</th><th>اسم البرنامج/المركز</th><th>الاسم الإنجليزي</th><th>الوصف</th><th>التأسيس/التعريف</th></tr></thead>
        <tbody id="tarteelProgramsBody"></tbody></table></div>`;
    oldCards.insertAdjacentElement("afterend", section);
    document.getElementById("tarteelProgramSearch").addEventListener("input", event => displayTarteelPrograms(event.target.value));
    displayTarteelPrograms();
}

// Replace the existing lecture cards with a real search field and an empty table.
function setupLecturesPage() {
    const main = document.querySelector("main");
    const oldCards = main && main.querySelector(":scope > .row.g-4");
    if (!main || !oldCards) return;
    const section = document.createElement("section");
    section.className = "mt-4";
    section.innerHTML = `
      <div class="mb-3"><label class="form-label fw-bold" for="tarteelLectureSearch">البحث في المحاضرات</label>
      <input id="tarteelLectureSearch" class="form-control" type="search" placeholder="ابحث بعنوان المحاضرة أو المحاضر أو المكان"></div>
      <div class="table-responsive"><table class="table table-striped table-bordered align-middle">
        <thead class="table-success"><tr><th>التصنيف</th><th>عنوان المحاضرة</th><th>المحاضر</th><th>التاريخ</th><th>الوقت</th><th>المكان</th></tr></thead>
        <tbody id="tarteelLecturesBody"></tbody></table></div>`;
    oldCards.insertAdjacentElement("afterend", section);
    document.getElementById("tarteelLectureSearch").addEventListener("input", event => displayTarteelLectures(event.target.value));
    displayTarteelLectures();
}

// Add the data-entry forms only to admin.html; public pages never get these forms.
function setupAdminPage() {
    if (!/admin\.html$/i.test(location.pathname)) return;
    const main = document.querySelector("main");
    if (!main || document.getElementById("tarteelAdminForms")) return;
    const section = document.createElement("section");
    section.id = "tarteelAdminForms";
    section.className = "card rounded-4 shadow-sm my-4";
    section.innerHTML = `
      <div class="card-header bg-white"><h2 class="h5 fw-bold text-tarteel mb-0">إضافة البرامج والمحاضرات</h2></div>
      <div class="card-body"><div class="row g-4">
        <div class="col-lg-6"><h3 class="h6 fw-bold">إضافة برنامج</h3>
          <form id="adminProgramForm" class="row g-2" novalidate>
            <div class="col-12"><label for="adminProgramName" class="form-label">اسم البرنامج/المركز</label><input id="adminProgramName" class="form-control" required minlength="3"></div>
            <div class="col-12"><label for="adminProgramDescription" class="form-label">الوصف</label><textarea id="adminProgramDescription" class="form-control" required minlength="5"></textarea></div>
            <div class="col-12"><button class="btn btn-success" type="submit">إضافة البرنامج</button></div>
          </form>
        </div>
        <div class="col-lg-6"><h3 class="h6 fw-bold">إضافة محاضرة</h3>
          <form id="adminLectureForm" class="row g-2" novalidate>
            <div class="col-md-6"><label for="adminLectureTitle" class="form-label">عنوان المحاضرة</label><input id="adminLectureTitle" class="form-control" required minlength="3"></div>
            <div class="col-md-6"><label for="adminLectureSpeaker" class="form-label">المحاضر</label><input id="adminLectureSpeaker" class="form-control" required minlength="3"></div>
            <div class="col-md-6"><label for="adminLectureDate" class="form-label">التاريخ</label><input id="adminLectureDate" class="form-control" type="date" required></div>
            <div class="col-md-6"><label for="adminLectureTime" class="form-label">الوقت</label><input id="adminLectureTime" class="form-control" type="time" required></div>
            <div class="col-12"><label for="adminLectureLocation" class="form-label">المكان</label><input id="adminLectureLocation" class="form-control" required minlength="2"></div>
            <div class="col-12"><button class="btn btn-success" type="submit">إضافة المحاضرة</button></div>
          </form>
        </div></div>
        <p class="small text-secondary mt-3 mb-0">الحفظ محلي في هذا المتصفح لهذه المرحلة، وسيتم استبداله بقاعدة بيانات PHP وMySQL في الجزء الرابع.</p>
      </div>`;
    main.appendChild(section);

    document.getElementById("adminProgramForm").addEventListener("submit", event => {
        event.preventDefault();
        const name = document.getElementById("adminProgramName").value.trim();
        const description = document.getElementById("adminProgramDescription").value.trim();
        if (name.length < 3 || description.length < 5) { alert("يرجى إدخال اسم ووصف صحيحين."); return; }
        const nextNumber = String(Math.max(0, ...tarteelPrograms.map(p => Number(p.number) || 0)) + 1).padStart(2, "0");
        tarteelPrograms.push(new TarteelProgram(nextNumber, name, "", description, "أضيف حديثاً"));
        saveTarteelData();
        event.target.reset();
        alert("تمت إضافة البرنامج. افتح صفحة البرامج لعرضه في الجدول.");
    });

    document.getElementById("adminLectureForm").addEventListener("submit", event => {
        event.preventDefault();
        const title = document.getElementById("adminLectureTitle").value.trim();
        const speaker = document.getElementById("adminLectureSpeaker").value.trim();
        const dateValue = document.getElementById("adminLectureDate").value;
        const time = document.getElementById("adminLectureTime").value;
        const place = document.getElementById("adminLectureLocation").value.trim();
        if (title.length < 3 || speaker.length < 3 || !dateValue || !time || place.length < 2) { alert("يرجى إكمال جميع بيانات المحاضرة."); return; }
        const date = new Date(dateValue + "T00:00:00").toLocaleDateString("ar-OM");
        const category = "محاضرة جديدة";
        tarteelLectures.push(new TarteelLecture(category, title, "", speaker, date, time, place));
        saveTarteelData();
        event.target.reset();
        alert("تمت إضافة المحاضرة. افتح صفحة المحاضرات لعرضها في الجدول.");
    });
}

// Run the setup function that matches the currently loaded HTML page.
document.addEventListener("DOMContentLoaded", function () {
    const page = location.pathname.toLowerCase();
    if (page.endsWith("programs.html")) setupProgramsPage();
    if (page.endsWith("lectures.html")) setupLecturesPage();
    if (page.endsWith("admin.html")) setupAdminPage();
});
