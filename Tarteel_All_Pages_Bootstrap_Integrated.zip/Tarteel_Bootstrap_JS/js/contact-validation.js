/*
  Tarteel - Contact Form Validation
  The form's required fields and Bootstrap feedback messages are validated here.
  Three different validation rules are used: name length/pattern, email format, and message length.
*/
document.addEventListener("DOMContentLoaded", function () {
    const contactForm = document.querySelector("form.needs-validation");
    if (!contactForm) return;

    contactForm.addEventListener("submit", function (event) {
        const nameField = document.getElementById("name");
        const emailField = document.getElementById("email");
        const messageField = document.getElementById("message");

        // Names must contain at least three Arabic or English letters and spaces only.
        const namePattern = /^[\u0600-\u06FFa-zA-Z ]{3,50}$/;
        // The browser's email input type is supplemented by this explicit pattern.
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

        nameField.setCustomValidity(namePattern.test(nameField.value.trim()) ? "" : "الاسم يجب أن يتكون من 3 إلى 50 حرفاً.");
        emailField.setCustomValidity(emailPattern.test(emailField.value.trim()) ? "" : "يرجى إدخال بريد إلكتروني صحيح.");
        messageField.setCustomValidity(messageField.value.trim().length >= 10 ? "" : "الرسالة يجب ألا تقل عن 10 أحرف.");

        // If any field is invalid, stop the form from submitting and show Bootstrap feedback.
        if (!contactForm.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }

        contactForm.classList.add("was-validated");
    });

    // Remove a custom error as soon as the user corrects its field.
    ["name", "email", "message"].forEach(function (fieldId) {
        const field = document.getElementById(fieldId);
        field.addEventListener("input", function () {
            field.setCustomValidity("");
        });
    });
});
