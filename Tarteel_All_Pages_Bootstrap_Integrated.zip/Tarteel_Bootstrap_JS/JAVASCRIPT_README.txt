Tarteel - Part III JavaScript files

External JavaScript connections:
- index.html -> js/home.js
  Creates the welcome/date/time moving banner and rotating gallery.
- programs.html -> js/dynamic-tables.js
  Keeps the original program cards and registration modals, then adds a dynamic searchable table generated from the programs array.
- lectures.html -> js/dynamic-tables.js
  Keeps the original lecture cards, then adds a dynamic searchable table generated from the lectures array.
- admin.html -> js/dynamic-tables.js
  Adds the program and lecture entry forms ONLY on the admin page. Submitted items are saved to localStorage.
- contact-us.html -> js/contact-validation.js
  Validates name, email and message and displays Bootstrap validation feedback.

The two constructor functions and initialized arrays are in dynamic-tables.js.
The two display functions are displayTarteelPrograms() and displayTarteelLectures().

Important limitation for Part III:
localStorage is only a browser-local demonstration. To share data between different visitors/devices, use the PHP + MySQL backend in Part IV. Run the project from the same local web server/origin when testing pages so that the browser shares the same localStorage between admin.html, programs.html and lectures.html.

Questionnaire, calculate and funpage are separate required pages in the Part III brief and are not included in this JavaScript-only correction.
