/*
  Tarteel - Homepage JavaScript
  Adds the moving welcome/date banner and automatic photo gallery.
*/

// Gallery images used by the homepage slideshow.
const tarteelGallery = [
    { src: "images/gallery-1.png", alt: "مصحف مفتوح", caption: "رحلة تعلم وتدبر" },
    { src: "images/gallery-2.png", alt: "مسجد وقت الغروب", caption: "مجالس علم وسكينة" },
    { src: "images/gallery-3.png", alt: "مكتبة وكتب علمية", caption: "العلم نور وهداية" }
];

let tarteelGalleryIndex = 0;

// Create a welcome banner that moves from the right edge to the left edge.
function createTarteelWelcomeBanner() {
    const footer = document.querySelector("footer");
    if (!footer || document.getElementById("tarteelWelcomeBanner")) return;

    const banner = document.createElement("div");
    banner.id = "tarteelWelcomeBanner";
    banner.setAttribute("aria-label", "رسالة الترحيب والتاريخ والوقت");

    const movingText = document.createElement("div");
    movingText.id = "tarteelMovingTrack";

    const welcomeText = document.createElement("span");
    welcomeText.textContent = "أهلاً بكم في منصة ترتيل 🌿  |  ";

    const dateTime = document.createElement("span");
    dateTime.id = "tarteelCurrentDateTime";

    movingText.append(welcomeText, dateTime);
    banner.appendChild(movingText);

    const style = document.createElement("style");
    style.textContent = `
        #tarteelWelcomeBanner {
            width: 100%;
            height: 80px;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            background: #075342;
            color: #ffffff;
            direction: ltr;
            white-space: nowrap;
        }
        #tarteelMovingTrack {
            position: absolute;
            left: 0;
            width: max-content;
            display: inline-block;
            color: #ffffff;
            font-family: inherit;
            font-size: 24px;
            font-weight: 700;
            line-height: 1.5;
            white-space: nowrap;
            will-change: transform;
            animation: tarteelFullMarquee 22s linear infinite;
        }
        @keyframes tarteelFullMarquee {
            from { transform: translateX(100vw); }
            to { transform: translateX(-100%); }
        }
        @media (max-width: 576px) {
            #tarteelMovingTrack { font-size: 19px; animation-duration: 25s; }
        }
        @media (prefers-reduced-motion: reduce) {
            #tarteelMovingTrack {
                position: static;
                width: 100%;
                text-align: center;
                white-space: normal;
                animation: none;
            }
            #tarteelWelcomeBanner { height: auto; min-height: 80px; padding: 12px; }
        }
    `;
    document.head.appendChild(style);

    // Put the banner immediately before the footer.
    footer.parentNode.insertBefore(banner, footer);
}

// Create the rotating gallery immediately before the footer.
function createTarteelGallery() {
    const footer = document.querySelector("footer");
    if (!footer || document.getElementById("tarteelGallerySection")) return;

    const section = document.createElement("section");
    section.className = "container py-4 text-center";
    section.id = "tarteelGallerySection";

    const heading = document.createElement("h2");
    heading.className = "h3 fw-bold text-tarteel mb-3";
    heading.textContent = "معرض ترتيل";

    const image = document.createElement("img");
    image.id = "tarteelGalleryImage";
    image.src = tarteelGallery[0].src;
    image.alt = tarteelGallery[0].alt;
    image.className = "img-fluid rounded-4 shadow";
    image.style.maxHeight = "380px";
    image.style.width = "100%";
    image.style.objectFit = "cover";

    const caption = document.createElement("p");
    caption.id = "tarteelGalleryCaption";
    caption.className = "mt-3 fw-bold text-tarteel";
    caption.textContent = tarteelGallery[0].caption;

    section.append(heading, image, caption);
    footer.parentNode.insertBefore(section, footer);
}

// Show the current date and time in Arabic and refresh it every second.
function updateTarteelDateTime() {
    const output = document.getElementById("tarteelCurrentDateTime");
    if (!output) return;

    const now = new Date();
    const date = now.toLocaleDateString("ar-OM", {
        year: "numeric",
        month: "long",
        day: "numeric"
    });
    const time = now.toLocaleTimeString("ar-OM", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
        });

    output.textContent = "التاريخ: " + date + "  |  الوقت: " + time;
}

// Move to the next image; return to the first image after the third one.
function showNextTarteelImage() {
    tarteelGalleryIndex = (tarteelGalleryIndex + 1) % tarteelGallery.length;

    const image = document.getElementById("tarteelGalleryImage");
    const caption = document.getElementById("tarteelGalleryCaption");

    if (image && caption) {
        image.src = tarteelGallery[tarteelGalleryIndex].src;
        image.alt = tarteelGallery[tarteelGalleryIndex].alt;
        caption.textContent = tarteelGallery[tarteelGalleryIndex].caption;
    }
}

// Start homepage features after the HTML document is ready.
document.addEventListener("DOMContentLoaded", function () {
    createTarteelGallery();
    createTarteelWelcomeBanner();
    updateTarteelDateTime();

    setInterval(updateTarteelDateTime, 1000);
    setInterval(showNextTarteelImage, 3000);
});
